<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// plugin settings side data fetching

// Register GraphQL fields
add_action('graphql_register_types', function () {
    register_graphql_field('RootQuery', 'advancedSimpleSEOSettings', [
        'type' => ['list_of' => 'SEOSetting'],
        'description' => 'All Advanced Simple SEO settings',
        'resolve' => function () {
            $settings = [
                'asseo_website_name',
                'asseo_tagline',
                'asseo_title_separator',
                'asseo_site_image',
                'asseo_default_meta_title',
                'asseo_default_meta_description',
                'asseo_default_meta_keywords',
                'asseo_gsite_verification',
                'asseo_ganalytics',
                'asseo_g4analytics',
                'asseo_bing',
                'asseo_yandex',
                'asseo_baidu',
                'asseo_pinterest',
                'asseo_robot_noindex',
                'asseo_robot_nofollow',
                'asseo_fb_app_id',
                'asseo_fb_title',
                'asseo_fb_description',
                'asseo_fb_image',
                'asseo_twitter_username',
                'asseo_tw_title',
                'asseo_tw_description',
                'asseo_tw_image',
                'asseo_canonical_url',
                'asseo_generate_sitemap',
                'asseo_sitemap_post_types',
                'header_code',
                'body_code',
                'footer_code',
                'asseo_redirect_from_url',
                'asseo_redirect_to_url',
                'asseo_redirect_type',
                'asseo_remove_shortlinks',
                'asseo_remove_rest_api',
                'asseo_remove_rsd_wlw',
                'asseo_oembed',
                'asseo_generator_tag',
                'asseo_pingback_http_header',
                'asseo_powered_by_http',
                'asseo_global_feed',
                'asseo_global_comment_feed',
                'asseo_post_comment_feed',
                'asseo_post_authors_feed',
                'asseo_category_feed',
                'asseo_tag_feeds',
                'asseo_taxonomy_feeds',
                'asseo_Search_results_feeds',
                'asseo_atom_rdf_feeds',
                'asseo_emoji_scripts',
                'asseo_wpjson_api',
                'asseo_breadcrumbs_active',
                'asseo_between_breadcrumbs',
                'asseo_anchor_text',
                'asseo_prefix_breadcrumb_path',
                'asseo_none',
                'asseo_organization',
                'asseo_person',
                'asseo_organization_name',
                'asseo_organization_logo',
                'asseo_users',
                'asseo_person_logo',
            ];

            $response = [];
            foreach ($settings as $setting) {
                $response[] = [
                    'key' => $setting,
                    'value' => get_option($setting),
                ];
            }
            return $response;
        },
    ]);

    register_graphql_object_type('SEOSetting', [
        'description' => 'SEO Setting Key-Value Pair',
        'fields' => [
            'key' => ['type' => 'String'],
            'value' => ['type' => 'String'],
        ],
    ]);
});


// Post/page individual data fetching

add_action('graphql_register_types', function () {
    register_graphql_field('Post', 'seoMeta', [
        'type' => 'SEOData',
        'description' => 'SEO Meta Data for the post',
        'resolve' => function ($post) {
            return [
                'meta_title' => esc_html(get_post_meta($post->ID, 'asseo_meta_title', true)),
                'meta_description' => esc_html(get_post_meta($post->ID, 'asseo_meta_description', true)),
                'canonical_url' => esc_html(get_post_meta($post->ID, 'asseo_canonical_url', true)),
                'meta_keywords' => esc_html(get_post_meta($post->ID, 'asseo_meta_keywords', true)),
                'robot_noindex' => esc_html(get_post_meta($post->ID, 'asseo_robot_noindex', true)),
                'robot_nofollow' => esc_html(get_post_meta($post->ID, 'asseo_robot_nofollow', true)),
                'facebook' => [
                    'title' => esc_html(get_post_meta($post->ID, 'asseo_fb_title', true)),
                    'description' => esc_html(get_post_meta($post->ID, 'asseo_fb_description', true)),
                    'image' => esc_html(get_post_meta($post->ID, 'asseo_fb_image', true)),
                ],
                'twitter' => [
                    'title' => esc_html(get_post_meta($post->ID, 'asseo_tw_title', true)),
                    'description' => esc_html(get_post_meta($post->ID, 'asseo_tw_description', true)),
                    'image' => esc_html(get_post_meta($post->ID, 'asseo_tw_image', true)),
                ],
            ];
        },
    ]);

    register_graphql_object_type('SEOData', [
        'description' => 'SEO Data for posts and pages',
        'fields' => [
            'meta_title' => ['type' => 'String'],
            'meta_description' => ['type' => 'String'],
            'canonical_url' => ['type' => 'String'],
            'meta_keywords' => ['type' => 'String'],
            'robot_noindex' => ['type' => 'Boolean'],
            'robot_nofollow' => ['type' => 'Boolean'],
            'facebook' => [
                'type' => 'FacebookSEO',
                'description' => 'Facebook SEO Meta',
            ],
            'twitter' => [
                'type' => 'TwitterSEO',
                'description' => 'Twitter SEO Meta',
            ],
        ],
    ]);

    register_graphql_object_type('FacebookSEO', [
        'description' => 'Facebook-specific SEO data',
        'fields' => [
            'title' => ['type' => 'String'],
            'description' => ['type' => 'String'],
            'image' => ['type' => 'String'],
        ],
    ]);

    register_graphql_object_type('TwitterSEO', [
        'description' => 'Twitter-specific SEO data',
        'fields' => [
            'title' => ['type' => 'String'],
            'description' => ['type' => 'String'],
            'image' => ['type' => 'String'],
        ],
    ]);
});
