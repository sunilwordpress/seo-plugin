<?php

add_action('wp_ajax_asseo_save_redirection', 'asseo_save_redirection_handler');
function asseo_save_redirection_handler()
{
    // Check the nonce for security
    check_ajax_referer('asseo_nonce', 'nonce');

    // Parse and sanitize the incoming data
    parse_str($_POST['data'], $form_data);

    // general tab
    if (isset($form_data['asseo_website_name'])) {
        update_option('blogname', sanitize_text_field($form_data['asseo_website_name']));
    }

    if (isset($form_data['asseo_tagline'])) {
        update_option('blogdescription', sanitize_text_field($form_data['asseo_tagline']));
    }

    if (isset($form_data['asseo_title_separator'])) {
        update_option('asseo_title_separator', sanitize_text_field($form_data['asseo_title_separator']));
    }

    if (isset($form_data['asseo_site_image'])) {
        update_option('asseo_site_image', esc_url_raw($form_data['asseo_site_image']));
    }

    // meta tab
    if (isset($form_data['asseo_default_meta_title'])) {
        update_option('asseo_default_meta_title', sanitize_text_field($form_data['asseo_default_meta_title']));
    }

    if (isset($form_data['asseo_default_meta_description'])) {
        update_option('asseo_default_meta_description', sanitize_textarea_field($form_data['asseo_default_meta_description']));
    }

    if (isset($form_data['asseo_default_meta_keywords'])) {
        update_option('asseo_default_meta_keywords', sanitize_text_field($form_data['asseo_default_meta_keywords']));
    }

    if (isset($form_data['asseo_ai_meta_active'])) {
        update_option('asseo_ai_meta_active', $form_data['asseo_ai_meta_active']);
    }

    if (isset($form_data['asseo_ai_meta_key'])) {
        update_option('asseo_ai_meta_key', sanitize_text_field($form_data['asseo_ai_meta_key']));
    }

    // sitemap tab
    if (isset($form_data['asseo_generate_sitemap'])) {
        update_option('asseo_generate_sitemap', $form_data['asseo_generate_sitemap']);
    }

    if (isset($form_data['asseo_sitemap_post_types'])) {
        update_option('asseo_sitemap_post_types', $form_data['asseo_sitemap_post_types']);
    }

    // Analytics Tab
    if (isset($form_data['asseo_gsite_verification'])) {
        update_option('asseo_gsite_verification', sanitize_text_field($form_data['asseo_gsite_verification']));
    }

    if (isset($form_data['asseo_ganalytics'])) {
        update_option('asseo_ganalytics', sanitize_text_field($form_data['asseo_ganalytics']));
    }

    if (isset($form_data['asseo_g4analytics'])) {
        update_option('asseo_g4analytics', sanitize_text_field($form_data['asseo_g4analytics']));
    }

    if (isset($form_data['asseo_bing'])) {
        update_option('asseo_bing', sanitize_text_field($form_data['asseo_bing']));
    }

    if (isset($form_data['asseo_yandex'])) {
        update_option('asseo_yandex', sanitize_text_field($form_data['asseo_yandex']));
    }

    if (isset($form_data['asseo_baidu'])) {
        update_option('asseo_baidu', sanitize_text_field($form_data['asseo_baidu']));
    }

    if (isset($form_data['asseo_pinterest'])) {
        update_option('asseo_pinterest', sanitize_text_field($form_data['asseo_pinterest']));
    }

    // Robots tab
    if (isset($form_data['asseo_robot_noindex'])) {
        update_option('asseo_robot_noindex', $form_data['asseo_robot_noindex']);
    }

    if (isset($form_data['asseo_robot_nofollow'])) {
        update_option('asseo_robot_nofollow', $form_data['asseo_robot_nofollow']);
    }

    // Facebook tab
    if (isset($form_data['asseo_fb_app_id'])) {
        update_option('asseo_fb_app_id', sanitize_text_field($form_data['asseo_fb_app_id']));
    }

    if (isset($form_data['asseo_fb_title'])) {
        update_option('asseo_fb_title', sanitize_text_field($form_data['asseo_fb_title']));
    }

    if (isset($form_data['asseo_fb_description'])) {
        update_option('asseo_fb_description', sanitize_textarea_field($form_data['asseo_fb_description']));
    }

    if (isset($form_data['asseo_fb_image'])) {
        update_option('asseo_fb_image', esc_url_raw($form_data['asseo_fb_image']));
    }

    // Twitter tab
    if (isset($form_data['asseo_twitter_username'])) {
        update_option('asseo_twitter_username', sanitize_text_field($form_data['asseo_twitter_username']));
    }

    if (isset($form_data['asseo_tw_title'])) {
        update_option('asseo_tw_title', sanitize_text_field($form_data['asseo_tw_title']));
    }

    if (isset($form_data['asseo_tw_description'])) {
        update_option('asseo_tw_description', sanitize_textarea_field($form_data['asseo_tw_description']));
    }

    if (isset($form_data['asseo_tw_image'])) {
        update_option('asseo_tw_image', esc_url_raw($form_data['asseo_tw_image']));
    }

    // canonical URL tab
    if (isset($form_data['asseo_canonical_url'])) {
        update_option('asseo_canonical_url', esc_url_raw($form_data['asseo_canonical_url']));
    }

    // Redirects tab
    if (isset($form_data['asseo_redirect_from_url'])) {
        update_option('asseo_redirect_from_url', esc_url_raw($form_data['asseo_redirect_from_url']));
    }

    if (isset($form_data['asseo_redirect_to_url'])) {
        update_option('asseo_redirect_to_url', esc_url_raw($form_data['asseo_redirect_to_url']));
    }

    if (isset($form_data['asseo_redirect_type'])) {
        update_option('asseo_redirect_type', sanitize_text_field($form_data['asseo_redirect_type']));
    }

    // Header/Body/Footer Code tab
    if (isset($form_data['header_code'])) {
        update_option('header_code', sanitize_textarea_field($form_data['header_code']));
    }

    if (isset($form_data['body_code'])) {
        update_option('body_code', sanitize_textarea_field($form_data['body_code']));
    }

    if (isset($form_data['footer_code'])) {
        update_option('footer_code', sanitize_textarea_field($form_data['footer_code']));
    }

    // Remove shortlinks, REST API, etc.
    update_option('asseo_remove_shortlinks', isset($form_data['asseo_remove_shortlinks']) ? $form_data['asseo_remove_shortlinks'] : 0);
    update_option('asseo_remove_rest_api', isset($form_data['asseo_remove_rest_api']) ? $form_data['asseo_remove_rest_api'] : 0);
    update_option('asseo_remove_rsd_wlw', isset($form_data['asseo_remove_rsd_wlw']) ? $form_data['asseo_remove_rsd_wlw'] : 0);
    update_option('asseo_oembed', isset($form_data['asseo_oembed']) ? $form_data['asseo_oembed'] : 0);
    update_option('asseo_generator_tag', isset($form_data['asseo_generator_tag']) ? $form_data['asseo_generator_tag'] : 0);
    update_option('asseo_pingback_http_header', isset($form_data['asseo_pingback_http_header']) ? $form_data['asseo_pingback_http_header'] : 0);
    update_option('asseo_powered_by_http', isset($form_data['asseo_powered_by_http']) ? $form_data['asseo_powered_by_http'] : 0);

    // Feeds tab
    update_option('asseo_global_feed', isset($form_data['asseo_global_feed']) ? $form_data['asseo_global_feed'] : 0);
    update_option('asseo_global_comment_feed', isset($form_data['asseo_global_comment_feed']) ? $form_data['asseo_global_comment_feed'] : 0);
    update_option('asseo_post_comment_feed', isset($form_data['asseo_post_comment_feed']) ? $form_data['asseo_post_comment_feed'] : 0);
    update_option('asseo_post_authors_feed', isset($form_data['asseo_post_authors_feed']) ? $form_data['asseo_post_authors_feed'] : 0);
    update_option('asseo_category_feed', isset($form_data['asseo_category_feed']) ? $form_data['asseo_category_feed'] : 0);
    update_option('asseo_tag_feeds', isset($form_data['asseo_tag_feeds']) ? $form_data['asseo_tag_feeds'] : 0);
    update_option('asseo_taxonomy_feeds', isset($form_data['asseo_taxonomy_feeds']) ? $form_data['asseo_taxonomy_feeds'] : 0);
    update_option('asseo_search_results_feeds', isset($form_data['asseo_search_results_feeds']) ? $form_data['asseo_search_results_feeds'] : 0);
    update_option('asseo_atom_rdf_feeds', isset($form_data['asseo_atom_rdf_feeds']) ? $form_data['asseo_atom_rdf_feeds'] : 0);

    // Emoji scripts
    update_option('asseo_emoji_scripts', isset($form_data['asseo_emoji_scripts']) ? $form_data['asseo_emoji_scripts'] : 0);

    // WP JSON API
    update_option('asseo_wpjson_api', isset($form_data['asseo_wpjson_api']) ? $form_data['asseo_wpjson_api'] : 0);


    // Breadcrumbs tab
    if (isset($form_data['asseo_breadcrumbs_active'])) {
        // Checkbox is checked, so save 1
        update_option('asseo_breadcrumbs_active', 1);
    } else {
        // Checkbox is not checked, so save 0
        update_option('asseo_breadcrumbs_active', 0);
    }


    if (isset($form_data['asseo_between_breadcrumbs'])) {
        update_option('asseo_between_breadcrumbs', $form_data['asseo_between_breadcrumbs']);
    }

    if (isset($form_data['asseo_anchor_text'])) {
        update_option('asseo_anchor_text', sanitize_text_field($form_data['asseo_anchor_text']));
    }

    if (isset($form_data['asseo_prefix_breadcrumb_path'])) {
        update_option('asseo_prefix_breadcrumb_path', sanitize_text_field($form_data['asseo_prefix_breadcrumb_path']));
    }

    // Structured data tab
    // Update the options based on the selected radio button
    if (isset($form_data['asseo_none'])) {
        update_option('asseo_none', 'none'); // "None" option is selected
        update_option('asseo_organization', ''); // Clear organization option
        update_option('asseo_person', ''); // Clear person option
    }

    if (isset($form_data['asseo_organization'])) {
        update_option('asseo_organization', 'organization'); // Organization option is selected
        update_option('asseo_none', ''); // Clear none option
        update_option('asseo_person', ''); // Clear person option
    }

    if (isset($form_data['asseo_person'])) {
        update_option('asseo_person', 'person'); // Person option is selected
        update_option('asseo_none', ''); // Clear none option
        update_option('asseo_organization', ''); // Clear organization option
    }


    if (isset($form_data['asseo_organization_name'])) {
        update_option('asseo_organization_name', sanitize_text_field($form_data['asseo_organization_name']));
    }

    if (isset($form_data['asseo_organization_logo'])) {
        update_option('asseo_organization_logo', esc_url_raw($form_data['asseo_organization_logo']));
    }

    if (isset($form_data['asseo_person_logo'])) {
        update_option('asseo_person_logo', esc_url_raw($form_data['asseo_person_logo']));
    }

    if (isset($form_data['asseo_users'])) {
        update_option('asseo_users', sanitize_text_field($form_data['asseo_users']));
    }







    // Respond with success
    wp_send_json_success(array('message' => 'Settings saved successfully!'));

    // Always terminate the script after handling AJAX
    wp_die();
}
