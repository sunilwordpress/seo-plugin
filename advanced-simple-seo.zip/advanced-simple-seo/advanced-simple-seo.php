<?php
/*
Plugin Name: Advanced Simple SEO
Description: "Advanced Simple SEO" is a powerful yet user-friendly WordPress plugin designed to optimize your website's SEO with ease. Combining advanced features with simplicity, it offers a seamless experience for beginners and professionals alike. The plugin provides comprehensive tools to enhance your website's visibility, performance, and search rankings without overwhelming configurations.
Version: 1.1
Author: Saviom Team
*/

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
    exit;
}

define('ASSEO_TXTDOMAIN', 'advanced-simple-seo');
define('ASSEO_VERSION', '1.1');
define('ASSEO_PATH', plugin_dir_path(__FILE__));

// Autoloader
require_once ASSEO_PATH . 'autoloader.php';

// Include necessary files
require_once ASSEO_PATH . 'app/Admin/Meta/RedirectHandler.php';
require_once ASSEO_PATH . 'app/Admin/Meta/GeneralTabHandler.php';
require_once ASSEO_PATH . 'app/Admin/Meta/CrawlHandler.php';
require_once ASSEO_PATH . 'app/Admin/Meta/AdvancedHandler.php';
require_once ASSEO_PATH . 'app/Admin/Meta/seo-meta-description-ai.php';
require_once plugin_dir_path(__FILE__) . 'includes/rest-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/graphql.php';
require_once plugin_dir_path(__FILE__) . 'app/Admin/Meta/import-export.php';
// Include the external file management code
require_once plugin_dir_path(__FILE__) . 'app/Admin/Meta/asseo-file-management.php';
// Include bulk editor functionality if it's in a separate file
include_once plugin_dir_path(__FILE__) . 'app/Admin/Meta/bulk-editor.php'; 


use App\Admin\Meta\RedirectHandler;
use App\Admin\Meta\CrawlHandler;
use App\Admin\Meta\AdvancedHandler;
use App\Admin\Meta\GeneralTabHandler;
use App\Admin\Meta\seoMetaAI;

// Activation hook for creating the database table
register_activation_hook(__FILE__, 'asseo_create_redirect_table');


function asseo_create_redirect_table()
{
    global $wpdb;

    $table_name = $wpdb->prefix . 'asseo_redirects';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id MEDIUMINT(9) NOT NULL AUTO_INCREMENT,
        from_url VARCHAR(255) NOT NULL,
        to_url VARCHAR(255) NOT NULL,
        redirect_type VARCHAR(3) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// Initialize the main plugin class
add_action('plugins_loaded', function () {
    global $AdvancedSimpleSEO;

    // Ensure the main plugin class is loaded
    if (class_exists('app\AdvancedSimpleSEO')) {
        $AdvancedSimpleSEO = new app\AdvancedSimpleSEO();
    }

    // Initialize RedirectHandler
    if (class_exists('App\Admin\Meta\RedirectHandler')) {
        new RedirectHandler();
    }

    // Initialize GeneralTabHandler
    if (class_exists('App\Admin\Meta\GeneralTabHandler')) {
        new GeneralTabHandler();
    }

    // Initialize CrawlHandler
    if (class_exists('App\Admin\Meta\CrawlHandler')) {
        new CrawlHandler();
    }

    // Initialize AdvancedHandler
    if (class_exists('App\Admin\Meta\AdvancedHandler')) {
        new AdvancedHandler();
    }

    // Initialize seoMetaAI
    if (class_exists('App\Admin\Meta\seoMetaAI')) {
        new seoMetaAI();
    }
});

// Add custom header, body, and footer code
function asseo_add_header_code()
{
    $head_code = get_option('header_code');
    if (!empty($head_code)) {
        echo '<!-- Custom Header Code -->' . PHP_EOL;
        echo $head_code . PHP_EOL;
    }
}
add_action('wp_head', 'asseo_add_header_code');

function asseo_add_body_code()
{
    $body_code = get_option('body_code');
    if (!empty($body_code)) {
        echo '<!-- Custom Body Code -->' . PHP_EOL;
        echo $body_code . PHP_EOL;
    }
}
add_action('wp_body_open', 'asseo_add_body_code');

function asseo_add_footer_code()
{
    $footer_code = get_option('footer_code');
    if (!empty($footer_code)) {
        echo '<!-- Custom Footer Code -->' . PHP_EOL;
        echo $footer_code . PHP_EOL;
    }
}
add_action('wp_footer', 'asseo_add_footer_code');

// Enqueue admin scripts
function enqueue_asseo_admin_scripts($hook)
{
    wp_enqueue_media();

    wp_enqueue_script(
        'asseo-admin-script',
        get_home_url() . '/wp-content/plugins/advanced-simple-seo/js/mediaUploader.js',
        array('jquery', 'media-editor'),
        '1.0',
        true
    );

    // Pass plugin data to JavaScript
    wp_localize_script('asseo-admin-script', 'asseoPluginData', array(
        'pluginImagePath' => get_home_url() . '/wp-content/plugins/advanced-simple-seo/assets/image-upload.png',
        'homeUrl' => get_home_url(),
    ));
}
add_action('admin_enqueue_scripts', 'enqueue_asseo_admin_scripts');

// Meta API fetching and loading to the js file
function enqueue_metaapi_script()
{
    wp_enqueue_script('metaapi-script', plugin_dir_url(__FILE__) . 'app/Admin/Meta/js/seo-meta-description-ai-open-ai.js', array('jquery'), null, true);
    $api_key = get_option('asseo_ai_meta_key');
    wp_localize_script('metaapi-script', 'customVars', array(
        'API_KEY' => $api_key
    ));
}
add_action('admin_enqueue_scripts', 'enqueue_metaapi_script');


add_action('admin_notices', function () {
    if (isset($_GET['import']) && $_GET['import'] === 'success') {
        echo '<div class="notice notice-success is-dismissible">';
        echo '<p>' . __('Settings imported successfully!', 'asseo-textdomain') . '</p>';
        echo '</div>';
    }
});



add_action('admin_enqueue_scripts', 'asseo_enqueue_admin_scripts');
function asseo_enqueue_admin_scripts() {
    wp_enqueue_script('asseo-ajax-script', plugin_dir_url(__FILE__) . 'js/asseo-ajax.js', array('jquery'), '1.0', true);

    // Localize script to pass AJAX URL and nonce
    wp_localize_script('asseo-ajax-script', 'asseoAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('asseo_nonce')
    ));
}

// Ensure the file exists before including
if (file_exists(plugin_dir_path(__FILE__) . 'includes/ajax-handlers-for-main-submission.php')) {
    include_once plugin_dir_path(__FILE__) . 'includes/ajax-handlers-for-main-submission.php';
}






function enqueue_redirect_script() {
    // Ensure jQuery is loaded and enqueue the custom script
    wp_enqueue_script('jquery');
    wp_enqueue_script(
        'redirect-ajax-script',
        plugin_dir_url(__FILE__) . 'js/redirect.js',
        array('jquery'),
        null,
        true
    );

    // Localize script with necessary variables
    wp_localize_script('redirect-ajax-script', 'redirect_vars', array(
        'add_redirect_nonce' => wp_create_nonce('add_redirect_nonce'),
        'delete_redirect_nonce' => wp_create_nonce('delete_redirect_nonce'),
        'ajax_url' => admin_url('admin-ajax.php'),
    ));
}
add_action('admin_enqueue_scripts', 'enqueue_redirect_script');

// Handle the 'add_redirect' AJAX request
add_action('wp_ajax_add_redirect', 'add_redirect_handler');
function add_redirect_handler() {
    // Verify nonce
    check_ajax_referer('add_redirect_nonce', '_wpnonce');

    global $wpdb;
    $table_name = $wpdb->prefix . 'asseo_redirects';

    // Sanitize and validate input
    $from_url = isset($_POST['from_url']) ? sanitize_text_field($_POST['from_url']) : '';
    $to_url = isset($_POST['to_url']) ? sanitize_text_field($_POST['to_url']) : '';
    $redirect_type = isset($_POST['redirect_type']) ? sanitize_text_field($_POST['redirect_type']) : '301';

    if (empty($from_url) || empty($to_url)) {
        wp_send_json_error(['message' => 'Both From URL and To URL are required.']);
    }

    if (!filter_var($from_url, FILTER_VALIDATE_URL)) {
        wp_send_json_error(['message' => 'Invalid From URL.']);
    }

    if (!filter_var($to_url, FILTER_VALIDATE_URL)) {
        wp_send_json_error(['message' => 'Invalid To URL.']);
    }

    // Insert data into the database
    $inserted = $wpdb->insert($table_name, [
        'from_url' => $from_url,
        'to_url' => $to_url,
        'redirect_type' => $redirect_type,
    ]);

    if ($inserted === false) {
        error_log('Database insert failed: ' . $wpdb->last_error);
        wp_send_json_error(['message' => 'Failed to add redirect.']);
    }

    $id = $wpdb->insert_id;

    // Send success response
    wp_send_json_success([
        'id' => $id,
        'from_url' => $from_url,
        'to_url' => $to_url,
        'redirect_type' => $redirect_type,
    ]);
}


// Handle the 'delete_redirect' AJAX request
add_action('wp_ajax_delete_redirect', 'delete_redirect_handler');
function delete_redirect_handler() {
    // Verify nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'delete_redirect_nonce')) {
        wp_send_json_error(['message' => 'Invalid nonce.']);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'asseo_redirects';

    // Validate the redirect ID
    $redirect_id = isset($_POST['id']) ? intval($_POST['id']) : 0;

    if ($redirect_id <= 0) {
        wp_send_json_error(['message' => 'Invalid redirect ID.']);
    }

    // Attempt to delete the record
    $deleted = $wpdb->delete($table_name, ['id' => $redirect_id]);

    if ($deleted === false) { // If deletion failed
        error_log("Failed to delete redirect with ID: $redirect_id. DB Error: " . $wpdb->last_error);
        wp_send_json_error(['message' => 'Database error occurred while deleting redirect.']);
    } elseif ($deleted === 0) { // If no rows were affected
        error_log("No redirect found with ID: $redirect_id.");
        wp_send_json_error(['message' => 'No redirect found to delete.']);
    }

    // Successfully deleted
    wp_send_json_success(['message' => 'Redirect deleted successfully.']);
}




