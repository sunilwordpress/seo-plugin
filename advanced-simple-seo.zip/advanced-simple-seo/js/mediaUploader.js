// media uploader for site image
jQuery(document).ready(function($) {
    var mediaUploader;

    $("#asseo_site_image_upload").on("click", function(e) {
        e.preventDefault();
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        mediaUploader = wp.media({
            title: "Choose Site Image",
            button: {
                text: "Use this image"
            },
            multiple: false
        });
        mediaUploader.on("select", function() {
            var attachment = mediaUploader.state().get("selection").first().toJSON();
            $("#asseo_site_image").val(attachment.url);
            $("#asseo_site_image_preview").attr("src", attachment.url);
            $("#asseo_site_image_remove").show();
        });
        mediaUploader.open();
    });

    jQuery(document).ready(function($) {
        $("#asseo_site_image_remove").on("click", function(e) {
            e.preventDefault();
            $("#asseo_site_image").val("");
            // Use the localized plugin image path
            const defaultImagePath = asseoPluginData.pluginImagePath;
            $("#asseo_site_image_preview").attr("src", defaultImagePath);
            $(this).hide();
        });
    });
    
});


// media uploader for asseo_organization_logo_upload
jQuery(document).ready(function($) {
    var mediaUploader;

    $("#asseo_organization_logo_upload").on("click", function(e) {
        e.preventDefault();
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        mediaUploader = wp.media({
            title: "Choose Site Image",
            button: {
                text: "Use this image"
            },
            multiple: false
        });
        mediaUploader.on("select", function() {
            var attachment = mediaUploader.state().get("selection").first().toJSON();
            $("#asseo_organization_logo").val(attachment.url);
            $("#asseo_organization_logo_preview").attr("src", attachment.url);
            $("#asseo_organization_logo_remove").show();
        });
        mediaUploader.open();
    });

    jQuery(document).ready(function($) {
        $("#asseo_organization_logo_remove").on("click", function(e) {
            e.preventDefault();
            $("#asseo_organization_logo").val("");
            // Use the localized plugin image path
            const defaultImagePath = asseoPluginData.pluginImagePath;
            $("#asseo_organization_logo_preview").attr("src", defaultImagePath);
            $(this).hide();
        });
    });
    
});


// media uploader for asseo_person_logo_upload
jQuery(document).ready(function($) {
    var mediaUploader;

    $("#asseo_person_logo_upload").on("click", function(e) {
        e.preventDefault();
        if (mediaUploader) {
            mediaUploader.open();
            return;
        }
        mediaUploader = wp.media({
            title: "Choose Site Image",
            button: {
                text: "Use this image"
            },
            multiple: false
        });
        mediaUploader.on("select", function() {
            var attachment = mediaUploader.state().get("selection").first().toJSON();
            $("#asseo_person_logo").val(attachment.url);
            $("#asseo_person_logo_preview").attr("src", attachment.url);
            $("#asseo_person_logo_remove").show();
        });
        mediaUploader.open();
    });

    jQuery(document).ready(function($) {
        $("#asseo_person_logo_remove").on("click", function(e) {
            e.preventDefault();
            $("#asseo_person_logo").val("");
            // Use the localized plugin image path
            const defaultImagePath = asseoPluginData.pluginImagePath;
            $("#asseo_person_logo_preview").attr("src", defaultImagePath);
            $(this).hide();
        });
    });
    
});