jQuery(document).ready(function($) {
  $("#asseo-settings-form").on("submit", function(e) {
    e.preventDefault(); // Prevent default form submission

    // Collect form data
    var formData = $(this).serialize();

    // Make AJAX request
    $.ajax({
      url: asseoAjax.ajax_url, // AJAX URL from localized script
      type: "POST",
      data: {
        action: "asseo_save_redirection", // Action hook
        nonce: asseoAjax.nonce, // Security nonce
        data: formData // Serialized form data
      },
      beforeSend: function() {
        // Optional: Show a loading indicator
        $("#asseo-settings-form")
          .find('input[type="submit"]')
          .val("Saving...")
          .prop("disabled", true);

        // Clear previous notification
        $(".notice-form").text("").hide();
      },
      success: function(response) {
        if (response.success) {
          // Show success message in the notice-form
          $(".notice-form")
            .text("Settings saved successfully!")
            .css("color", "green")
            .show();

          // Remove notification after 2 seconds
          setTimeout(function() {
            $(".notice-form").fadeOut();
          }, 2000);
        } else {
          // Show error message in the notice-form
          $(".notice-form")
            .text("Error: " + response.data.message)
            .css("color", "red")
            .show();

          // Remove notification after 2 seconds
          setTimeout(function() {
            $(".notice-form").fadeOut();
          }, 2000);
        }
      },
      error: function() {
        // Show unexpected error message in the notice-form
        $(".notice-form")
          .text("An unexpected error occurred. Please try again.")
          .css("color", "red")
          .show();

        // Remove notification after 2 seconds
        setTimeout(function() {
          $(".notice-form").fadeOut();
        }, 2000);
      },
      complete: function() {
        // Reset submit button
        $("#asseo-settings-form")
          .find('input[type="submit"]')
          .val("Save Changes")
          .prop("disabled", false);
      }
    });
  });
});
