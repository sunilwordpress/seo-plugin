(function($) {
  "use strict";

  updatePreview();

  if ($("#asseoDefaultMetaTitle").length) {
    $("#asseo_title_count").html(
      "<strong>" + $("#asseoDefaultMetaTitle").val().length + "</strong>"
    );
  }

  if ($("#asseoDefaultMetaDescription").length) {
    $("#asseo_desc_count").html(
      "<strong>" + $("#asseoDefaultMetaDescription").val().length + "</strong>"
    );
  }

  if ($("#asseoMetaTitle").length) {
    $("#asseo_title_count").html(
      "<strong>" + $("#asseoMetaTitle").val().length + "</strong>"
    );
  }

  if ($("#asseoMetaDescription").length) {
    $("#asseo_desc_count").html(
      "<strong>" + $("#asseoMetaDescription").val().length + "</strong>"
    );
  }

  $("#asseoMetaTitle").change(function() {
    var count = $(this).val().length;
    $("#asseo_title_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });
  $("#asseoMetaTitle").keypress(function() {
    var count = $(this).val().length;
    $("#asseo_title_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });
  $("#asseoMetaTitle").bind("paste", function() {
    var count = $(this).val().length;
    $("#asseo_title_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });

  $("#asseoDefaultMetaTitle").change(function() {
    var count = $(this).val().length;
    $("#asseo_title_count").html("<strong>" + count + "</strong>");
  });
  $("#asseoDefaultMetaTitle").keypress(function() {
    var count = $(this).val().length;
    $("#asseo_title_count").html("<strong>" + count + "</strong>");
  });
  $("#asseoDefaultMetaTitle").bind("paste", function() {
    var count = $(this).val().length;
    $("#asseo_title_count").html("<strong>" + count + "</strong>");
  });

  $("#asseoMetaDescription").change(function() {
    var count = $(this).val().length;
    $("#asseo_desc_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });
  $("#asseoMetaDescription").keypress(function() {
    var count = $(this).val().length;
    $("#asseo_desc_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });
  $("#asseoMetaDescription").bind("paste", function() {
    var count = $(this).val().length;
    $("#asseo_desc_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });

  $("#asseoMetaDescription").change(function() {
    var count = $(this).val().length;
    $("#asseo_desc_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });
  $("#asseoMetaDescription").keypress(function() {
    var count = $(this).val().length;
    $("#asseo_desc_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });
  $("#asseoMetaDescription").bind("paste", function() {
    var count = $(this).val().length;
    $("#asseo_desc_count").html("<strong>" + count + "</strong>");
    updatePreview();
  });

  $("#title").change(function() {
    updatePreview();
  });
  $("#title").keypress(function() {
    updatePreview();
  });
  $("#title").bind(function() {
    updatePreview();
  });

  function updatePreview() {
    $("#asseo_snippet_title").html("");

    var asseoMetaDescription = $.trim($("#asseoMetaDescription").val());
    if (asseoMetaDescription.length > 0) {
      $("#asseo_snippet_description").html(asseoMetaDescription);
    }

    var asseoMetaTitle = $.trim($("#asseoMetaTitle").val());
    if (asseoMetaTitle.length > 0) {
      $("#asseo_snippet_title").html(asseoMetaTitle);
    }

    if (asseoMetaTitle.length <= 0) {
      var title = $.trim($("#title").val());
      if (title.length > 0) {
        $("#asseo_snippet_title").html(title);
      }
    }
  }

  if ($("#asseo-fb-image").val()) {
    $("#asseo-fb-media-remove").show();
    $("#asseo_fb_media_manager").hide();
  } else {
    $("#asseo-fb-media-remove").hide();
    $("#asseo_fb_media_manager").show();
  }

  if ($("#asseo-tw-image").val()) {
    $("#asseo-tw-media-remove").show();
    $("#asseo_tw_media_manager").hide();
  } else {
    $("#asseo-tw-media-remove").hide();
    $("#asseo_tw_media_manager").show();
  }

  $("#asseo_fb_media_manager").click(function() {
    var send_attachment_bkp = wp.media.editor.send.attachment;
    var button = $(this);
    wp.media.editor.send.attachment = function(props, attachment) {
      $(".fb-img-container").append(
        '<img id="asseo-fb-preview-image" src="' +
          attachment.url +
          '" class="media-input" />'
      );
      $("#asseo-fb-image").val(attachment.id);
      $("#asseo-fb-media-remove").show();
      $("#asseo_fb_media_manager").hide();
      wp.media.editor.send.attachment = send_attachment_bkp;
    };
    wp.media.editor.open(button);
    return false;
  });

  $("#asseo_tw_media_manager").click(function() {
    var send_attachment_bkp = wp.media.editor.send.attachment;
    var button = $(this);
    wp.media.editor.send.attachment = function(props, attachment) {
      $(".tw-img-container").append(
        '<img id="asseo-tw-preview-image" src="' +
          attachment.url +
          '" class="media-input" />'
      );
      $("#asseo-tw-image").val(attachment.id);
      $("#asseo-tw-media-remove").show();
      $("#asseo_tw_media_manager").hide();
      wp.media.editor.send.attachment = send_attachment_bkp;
    };
    wp.media.editor.open(button);
    return false;
  });

  $("#asseo-fb-media-remove").click(function() {
    var answer = confirm("Are you sure?");
    if (answer == true) {
      $(".fb-img-container").empty();
      $("#asseo-fb-image").val(" ");
      $("#asseo-fb-media-remove").hide();
      $("#asseo_fb_media_manager").show();
    }
    return false;
  });

  $("#asseo-tw-media-remove").click(function() {
    var answer = confirm("Are you sure?");
    if (answer == true) {
      $(".tw-img-container").empty();
      $("#asseo-tw-image").val(" ");
      $("#asseo-tw-media-remove").hide();
      $("#asseo_tw_media_manager").show();
    }
    return false;
  });
})(jQuery);


document.querySelectorAll('.nav-tab').forEach(tab => {
  tab.addEventListener('click', function(event) {
      // Prevent the default behavior of the anchor tags (like page jump)
      event.preventDefault();

      // Check if the clicked tab is 'redirection' or 'tools'
      const lastTwoTabs = ['#redirection', '#tools'];
      const clickedTab = tab.getAttribute('href');

      // If the clicked tab is one of the last two, hide the submit buttons
      if (lastTwoTabs.includes(clickedTab)) {
          document.querySelectorAll('.submit-btn').forEach(button => {
              button.style.display = 'none'; // Force hide
          });
      } else {
          // Otherwise, show the submit buttons
          document.querySelectorAll('.submit-btn').forEach(button => {
              button.style.display = 'block'; // Force show
          });
      }

      // Optionally add the "active" class to clicked tab and remove from others
      document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('nav-tab-active'));
      tab.classList.add('nav-tab-active');
  });
});

