jQuery(document).ready(function($) {
    $("#add_redirect_button").click(function() {
       var from_url = $('input[name="asseo_redirect_from_url"]').val();
       var to_url = $('input[name="asseo_redirect_to_url"]').val();
       var redirect_type = $('select[name="asseo_redirect_type"]').val();
 
       // Validate the form data
       if (from_url === "" || to_url === "") {
          alert("Please fill in both the From URL and To URL fields.");
          return;
       }
 
       // Submit data via AJAX
       $.ajax({
          url: redirect_vars.ajax_url,
          method: "POST",
          data: {
             action: "add_redirect",
             from_url: from_url,
             to_url: to_url,
             redirect_type: redirect_type,
             _wpnonce: redirect_vars.add_redirect_nonce
          },
          success: function(response) {
             if (response.success) {
                // Add the new redirect to the table dynamically
                var newRow = `
                   <tr>
                      <td>${response.data.from_url}</td>
                      <td>${response.data.to_url}</td>
                      <td>${response.data.redirect_type}</td>
                      <td>
                         <a href="#" class="delete-redirect" data-id="${response.data.id}" style="color: red; border: 1px solid; padding: 2px 10px; border-radius: 2px; text-decoration: none; line-height: normal; vertical-align: middle;">Delete</a>
                      </td>
                   </tr>
                `;
 
                // Append the new row to the table
                $(".wp-list-table tbody").append(newRow);
 
                // Clear the form fields
                $('input[name="asseo_redirect_from_url"]').val("");
                $('input[name="asseo_redirect_to_url"]').val("");
                $('select[name="asseo_redirect_type"]').val("301"); // Reset to default value
             } else {
                console.error("Error adding redirect:", response.data.message || "Unknown error");
                alert("Error adding redirect: " + (response.data.message || "Unknown error"));
             }
          },
          error: function(xhr, status, error) {
             console.error("AJAX Error:", error, xhr.responseText);
             alert("AJAX Error: " + error);
          }
       });
    });
 
    $(document).on("click", ".delete-redirect", function(e) {
       e.preventDefault();
       var redirectId = $(this).data("id");
 
       if (!redirectId) {
          console.error("No redirect ID provided.");
          return;
       }
 
       // Send the AJAX request to delete the redirect
       $.ajax({
          url: redirect_vars.ajax_url,
          type: "POST",
          data: {
             action: "delete_redirect",
             id: redirectId,
             _wpnonce: redirect_vars.delete_redirect_nonce
          },
          success: function(response) {
             if (response.success) {
                // Remove the row from the table
                $(`.delete-redirect[data-id="${redirectId}"]`).closest("tr").remove();
             } else {
                console.error("Error deleting redirect:", response.data.message || "Unknown error");
                alert("Error deleting redirect: " + (response.data.message || "Unknown error"));
             }
          },
          error: function(xhr, status, error) {
             console.error("AJAX Error:", xhr.responseText || error);
             alert("AJAX Error: " + (xhr.responseText || error));
          }
       });
    });
 });
 