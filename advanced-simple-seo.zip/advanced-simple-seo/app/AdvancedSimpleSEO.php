<?php 

namespace app;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}
class AdvancedSimpleSEO {

    function __construct() {
    	add_action('init', [$this, 'init']);
    }

    function init() {
		new init\init();
		new Admin\Admin();
	}

}

?>