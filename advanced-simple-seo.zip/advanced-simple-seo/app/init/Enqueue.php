<?php 

namespace app\init;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}

define('ASSEO_CSS_PATH', dirname(dirname(__FILE__))) . 'css' . DIRECTORY_SEPARATOR;
define('ASSEO_JS_PATH', dirname(dirname(__FILE__)) . 'js' . DIRECTORY_SEPARATOR);

class Enqueue {
	public $version = '';
	
	public function __construct() {
		$this->version = ASSEO_VERSION;

		if (is_admin()) {
			wp_enqueue_style(
				'asseo_admin_style', 
				plugins_url('css/style.css', ASSEO_CSS_PATH), 
				false, 
				$this->version
			);
			
			wp_enqueue_script(
				'asseo_script', 
				plugins_url('js/script.js', ASSEO_JS_PATH), 
				['jquery'], 
				$this->version, 
				true
			);
			
			wp_enqueue_script(
				'asseo_quickedit', 
				plugins_url('js/quickedit.js', ASSEO_JS_PATH), 
				false, 
				$this->version, 
				true);
		}
	}

}