<?php 

namespace app\init;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
    exit;
}

// Ensure `get_home_path` is loaded to avoid errors.
if (!function_exists('get_home_path')) {
    require_once ABSPATH . 'wp-admin/includes/file.php';
}

class Sitemap {
    
    /**
     * Get the permalink for a given post ID.
     * 
     * @param int $id The post ID.
     * @return string The permalink or an empty string if inaccessible.
     */
    protected function getPermalinkFromId($id) {
        $post_status = get_post_status($id);
        $post_type = get_post_type_object(get_post_type($id));

        // Ensure the post is not private or inaccessible.
        if ($post_status === 'private' && $post_type !== null && !current_user_can($post_type->cap->read_private_posts)) {
            return '';
        }

        $url = get_permalink($id);
        return $url ?: ''; // Use the null coalescing operator for better readability.
    }
    
    /**
     * Generate the sitemap XML and save it to the root directory.
     */
    public function buildSitemap() {
        global $wpdb;

        // Initialize the XML structure.
        $xmlString = '<?xml version="1.0" encoding="UTF-8"?>';
        $xmlString .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">';

        // Prepare the post types filter.
        $postTypesQrStr = '';
        $postTypes = get_option('asseo_sitemap_post_types');
        if (is_array($postTypes)) {
            foreach ($postTypes as $postType) {
                $postTypesQrStr .= $wpdb->prepare(" OR p.post_type = %s", $postType); // Use $wpdb->prepare for SQL safety.
            }
        }

        // Build the query to fetch published posts.
        $qs = "SELECT
            p.ID,
            p.post_date_gmt
        FROM
            {$wpdb->posts} p
        WHERE
            p.post_password = ''
            AND p.post_status = 'publish'";
        
        if (!empty($postTypesQrStr)) {
            $qs .= " AND (" . substr($postTypesQrStr, 4) . ")"; // Trim the leading " OR".
        }

        $qs .= " ORDER BY p.post_date_gmt DESC";

        // Execute the query.
        $posts = $wpdb->get_results($qs);

        // Iterate through posts and generate XML entries.
        foreach ($posts as $post) {
            $permalink = $this->getPermalinkFromId($post->ID);
            if (empty($permalink)) {
                continue;
            }
            $xmlString .= '<url>';
            $xmlString .= '<loc>' . esc_url($permalink) . '</loc>';
            $xmlString .= '<lastmod>' . date('c', strtotime($post->post_date_gmt)) . '</lastmod>';
            $xmlString .= '<priority>0.80</priority>';
            $xmlString .= '</url>';
        }

        $xmlString .= '</urlset>';

        // Save the sitemap to the root directory.
        $path = get_home_path();
        $sitemapPath = $path . 'sitemap.xml';

        // Safely write the sitemap file.
        if (file_exists($sitemapPath)) {
            @unlink($sitemapPath); // Silently delete any existing sitemap.
        }
        $file = fopen($sitemapPath, 'w');
        if ($file) {
            fwrite($file, $xmlString);
            fclose($file);
        } else {
            error_log('Failed to write sitemap.xml to ' . $sitemapPath);
        }
    }
}

?>
