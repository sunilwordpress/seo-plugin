<?php 

namespace app\init;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}

use app\Admin\Meta as Meta;

class init {
	public $version = '';
	
	public function __construct() {
		$this->version = ASSEO_VERSION;
		$this->settings();
		new Enqueue();

		/* headings, content, column sorting */
		$post_types = get_post_types(['public' => true]);
		if (is_array($post_types)) {
			foreach($post_types as $post_type) {
				add_filter('manage_'.$post_type.'_posts_columns', [$this, 'columnHeading'], 10, 1);
				add_action('manage_'.$post_type.'_posts_custom_column', [$this, 'columnContent'], 10, 2);
				add_action('manage_edit-'.$post_type.'_sortable_columns', [$this, 'columnSort'], 10, 2);
			}
			unset($post_type);
		}
		
		/* Default metabox for posts/pages */
		add_action('add_meta_boxes', [$this, 'metaBoxes']);
		
		/* Taxonomies */
		add_action('category_add_form_fields', [$this, 'renderNewTaxonomyMetaBox']);
		add_action('category_edit_form_fields', [$this, 'renderEditTaxonomyMetaBox']);
		add_action('post_tag_add_form_fields', [$this, 'renderNewTaxonomyMetaBox']);
		add_action('post_tag_edit_form_fields', [$this, 'renderEditTaxonomyMetaBox']);
		
		/* Quick Edit */
		add_action('quick_edit_custom_box', [$this, 'renderQuickEditMetaBox']);

		/* WooCommerce */
		if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
			add_action('product_cat_add_form_fields', [$this, 'renderNewTaxonomyMetaBox']);
			add_action('product_cat_edit_form_fields', [$this, 'renderEditTaxonomyMetaBox']);
			add_action('product_tag_add_form_fields', [$this, 'renderNewTaxonomyMetaBox']);
			add_action('product_tag_edit_form_fields', [$this, 'renderEditTaxonomyMetaBox']);
		}
		
		/* Header, Title, Meta */
		add_action('wp_head', [$this, 'renderHeader']);
		$title = new Meta\Title();
		add_filter('pre_get_document_title', [$title, 'getTitle']);
		add_filter('wp_title', [$title, 'getTitle']);
		
		/* Analytics */
		add_filter('wp_head', [$this, 'renderAnalytics']);
		
		/* Sitemap */
		if (get_option('asseo_generate_sitemap') == true) {
			/* disable WordPress sitemaps in favor of SimpleSEO sitemap. */
			apply_filters('wp_sitemaps_enabled', false);
		}
	}
	
	private function settings() {
		register_setting('asseo-settings-group', 'asseo_website_name');
		register_setting('asseo-settings-group', 'asseo_tagline');
		register_setting('asseo-settings-group', 'asseo_title_separator');
		register_setting('asseo-settings-group', 'asseo_site_image');
		register_setting('asseo-settings-group', 'asseo_default_meta_title');
		register_setting('asseo-settings-group', 'asseo_default_meta_description');		
		register_setting('asseo-settings-group', 'asseo_default_meta_keywords');
		register_setting('asseo-settings-group', 'asseo_gsite_verification');
		register_setting('asseo-settings-group', 'asseo_ganalytics');
		register_setting('asseo-settings-group', 'asseo_g4analytics');
		register_setting('asseo-settings-group', 'asseo_bing');
		register_setting('asseo-settings-group', 'asseo_yandex');
		register_setting('asseo-settings-group', 'asseo_baidu');
		register_setting('asseo-settings-group', 'asseo_pinterest');
		register_setting('asseo-settings-group', 'asseo_robot_noindex');
		register_setting('asseo-settings-group', 'asseo_robot_nofollow');
		register_setting('asseo-settings-group', 'asseo_fb_app_id');
		register_setting('asseo-settings-group', 'asseo_fb_title');
		register_setting('asseo-settings-group', 'asseo_fb_description');
		register_setting('asseo-settings-group', 'asseo_fb_image');
		register_setting('asseo-settings-group', 'asseo_twitter_username');
		register_setting('asseo-settings-group', 'asseo_tw_image');
		register_setting('asseo-settings-group', 'asseo_tw_title');
		register_setting('asseo-settings-group', 'asseo_tw_description');
		register_setting('asseo-settings-group', 'asseo_tw_image');
		register_setting('asseo-settings-group', 'asseo_canonical_url');
		register_setting('asseo-settings-group', 'asseo_generate_sitemap');
		register_setting('asseo-settings-group', 'asseo_sitemap_post_types');
		register_setting('asseo-settings-group', 'header_code');
		register_setting('asseo-settings-group', 'body_code');
		register_setting('asseo-settings-group', 'footer_code');
		register_setting('asseo-settings-group', 'asseo_redirect_from_url');
		register_setting('asseo-settings-group', 'asseo_redirect_to_url');
		register_setting('asseo-settings-group', 'asseo_redirect_type');
		register_setting('asseo-settings-group', 'asseo_remove_shortlinks');
		register_setting('asseo-settings-group', 'asseo_remove_rest_api');
		register_setting('asseo-settings-group', 'asseo_remove_rsd_wlw');
		register_setting('asseo-settings-group', 'asseo_oembed');
		register_setting('asseo-settings-group', 'asseo_generator_tag');
		register_setting('asseo-settings-group', 'asseo_pingback_http_header');
		register_setting('asseo-settings-group', 'asseo_powered_by_http');
		register_setting('asseo-settings-group', 'asseo_global_feed');
		register_setting('asseo-settings-group', 'asseo_global_comment_feed');
		register_setting('asseo-settings-group', 'asseo_post_comment_feed');
		register_setting('asseo-settings-group', 'asseo_post_authors_feed');
		register_setting('asseo-settings-group', 'asseo_category_feed');
		register_setting('asseo-settings-group', 'asseo_tag_feeds');
		register_setting('asseo-settings-group', 'asseo_taxonomy_feeds');
		register_setting('asseo-settings-group', 'asseo_Search_results_feeds');
		register_setting('asseo-settings-group', 'asseo_atom_rdf_feeds');
		register_setting('asseo-settings-group', 'asseo_emoji_scripts');
		register_setting('asseo-settings-group', 'asseo_wpjson_api');
		register_setting('asseo-settings-group', 'asseo_breadcrumbs_active');
		register_setting('asseo-settings-group', 'asseo_between_breadcrumbs');
		register_setting('asseo-settings-group', 'asseo_anchor_text');
		register_setting('asseo-settings-group', 'asseo_prefix_breadcrumb_path');
		register_setting('asseo-settings-group', 'asseo_none');
		register_setting('asseo-settings-group', 'asseo_organization');
		register_setting('asseo-settings-group', 'asseo_person');
		register_setting('asseo-settings-group', 'asseo_organization_name');
		register_setting('asseo-settings-group', 'asseo_organization_logo');
		register_setting('asseo-settings-group', 'asseo_users');
		register_setting('asseo-settings-group', 'asseo_person_logo');
		register_setting('asseo-settings-group', 'asseo_ai_meta_key');
		register_setting('asseo-settings-group', 'asseo_ai_meta_active');
    }
	
	public function activate() {
    }
    
	public function deactivate() {
    }

	public function columnHeading($columns) {
		$columns['post_name'] = __('Post Name', ASSEO_TXTDOMAIN);
		$columns['seo_title'] = __('SEO Title', ASSEO_TXTDOMAIN);
		$columns['seo_description'] = __('Meta Description', ASSEO_TXTDOMAIN);
		return $columns;
	}
	public function columnContent($column, $post_id) {
		switch ($column) {
			case 'post_name':
				$post = get_post($post_id);
				echo esc_html($post->post_name);
				break;
			case 'seo_title':
				echo esc_html(get_post_meta($post_id, 'asseo_meta_title', true));
				break;
			case 'seo_description':
				echo esc_html(get_post_meta($post_id, 'asseoMetaDescription', true));
				break;
		}
	}

	public function columnSort($columns) {
		$columns['post_name'] = 'post_name';
		$columns['seo_title'] = 'seo_title';
		$columns['seo_description'] = 'seo_description';
		return $columns;
	}

	public function metaBoxes($postType) {
		add_meta_box(
			'simple-seo', 
			__('Advanced Simple SEO'), 
			[$this, 'renderMetaBox'],
			$postType
		);
	}

	public function renderMetaBox($post) {
		new Meta\Post($post);
	}

	public function renderNewTaxonomyMetaBox() {
		$Taxonomy = new Meta\Taxonomy();
		$Taxonomy->newMetaBox();
	}

	public function renderEditTaxonomyMetaBox($term) {
		$Taxonomy = new Meta\Taxonomy();
		$Taxonomy->editMetaBox($term);
	}

	public function renderQuickEditMetaBox($columnName) {
		new Meta\QuickEdit($columnName);
	}

	public function renderHeader() {
		if (!is_admin()) {
			new Meta\Header();
		}
	}

	public function renderAnalytics() {
		if (!is_admin()) {
			new Meta\Analytics();
		}
	}
	
}

?>