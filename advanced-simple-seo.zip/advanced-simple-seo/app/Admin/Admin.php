<?php

namespace app\Admin;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}

use app\Helpers\Import as Import;
use app\init\Sitemap as Sitemap;
class Admin
{

	public function __construct()
	{
		add_action('admin_menu', [$this, 'addMenu']);
		add_action('save_post', [$this, 'savePostData']);
		add_action('edit_attachment', [$this, 'savePostData']);
		add_action('add_attachment', [$this, 'savePostData']);
		add_action('edited_category', [$this, 'saveTaxonomy']);
		add_action('create_category', [$this, 'saveTaxonomy']);
		add_action('edited_post_tag', [$this, 'saveTaxonomy']);
		add_action('create_post_tag', [$this, 'saveTaxonomy']);

		/* Import */
		// $Import = new Import();
		// add_action('admin_post_asseo_allinone_import', [$Import, 'importAIOSEO']);
		// add_action('admin_post_asseo_rankmath_import', [$Import, 'importRanked']);
		// add_action('admin_post_asseo_yoast_import', [$Import, 'importYoast']);

		/* WooCommerce */
		if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
			add_action('edited_product_cat', [$this, 'saveTaxonomy']);
			add_action('create_product_cat', [$this, 'saveTaxonomy']);
			add_action('edited_product_tag', [$this, 'saveTaxonomy']);
			add_action('create_product_tag', [$this, 'saveTaxonomy']);
		}

		/* Sitemap */
		if (get_option('asseo_generate_sitemap') == true) {
			$sitemap = new Sitemap();
			add_action('publish_post', [$sitemap, 'buildSitemap']);
			add_action('edit_post', [$sitemap, 'buildSitemap']);
			add_action('delete_post', [$sitemap, 'buildSitemap']);
		}
		add_action('admin_post_asseo_create_sitemap', [$this, 'generateSiteMap']);
		add_action('admin_post_asseo_delete_sitemap', [$this, 'siteMapDelete']);
	}

	// public function addMenu() {
	// 	add_options_page(
	// 		__('SEO Options', ASSEO_TXTDOMAIN), 
	// 		__('Advanced Simple SEO', ASSEO_TXTDOMAIN), 
	// 		'manage_options', 
	// 		'simpleSEOAdminOptions', 
	// 		[$this, 'simpleSEOAdminOptions']);
	// }

	public function addMenu()
	{
		add_menu_page(
			__('SEO Options', ASSEO_TXTDOMAIN), // Page title
			__('Advanced Simple SEO', ASSEO_TXTDOMAIN), // Menu title
			'manage_options', // Capability
			'simpleSEOAdminOptions', // Menu slug
			[$this, 'simpleSEOAdminOptions'], // Callback function
			'dashicons-chart-line', // Icon URL or Dashicon class
			20 // Position
		);
	}


	public function simpleSEOAdminOptions()
	{
		new Meta\Options();
	}

	public function savePostData($postId)
	{
		/* verify nonce */
		if (!isset($_POST['asseo_nonce']) || !wp_verify_nonce($_POST['asseo_nonce'], ASSEO_PATH)) {
			return $postId;
		}

		if (wp_is_post_revision($postId)) {
			return $postId;
		}

		/* check autosave */
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return $postId;
		}

		/* Check permissions */
		if ($_POST['post_type'] == 'page') {
			if (!current_user_can('edit_page', $postId)) {
				return $postId;
			}
		} elseif (!current_user_can('edit_post', $postId)) {
			return $postId;
		}

		Save::savePost($postId);
	}

	public function saveTaxonomy($term)
	{
		Save::saveTaxonomy($term);
	}

	public function siteMapDelete()
	{
		$nonce = null;
		if (!empty($_REQUEST['_wpnonce'])) {
			$nonce = $_REQUEST['_wpnonce'];
		}

		// $path = get_home_path();

		// if (wp_verify_nonce($nonce) && current_user_can('administrator')) {
		// 	@unlink($path . 'sitemap.xml');
		// 	//wp_redirect('/wp-admin/options-general.php?page=simpleSEOAdminOptions&sitemap_deleted=1');
		// 	wp_redirect(admin_url('options-general.php?page=simpleSEOAdminOptions&sitemap_deleted=1'));
		// } else {
		// 	die(__('Failed Security Check, No no no!', ASSEO_TXTDOMAIN));
		// }

		$path = get_home_path() . 'sitemap.xml';

		if (wp_verify_nonce($nonce) && current_user_can('administrator')) {
			if (file_exists($path)) {
				@unlink($path);
			}
			wp_redirect(admin_url('options-general.php?page=simpleSEOAdminOptions&sitemap_deleted=1'));
			exit;
		} else {
			die(__('Failed Security Check, No no no!', ASSEO_TXTDOMAIN));
		}

	}

	public function generateSiteMap()
	{
		$nonce = null;
		if (!empty($_REQUEST['_wpnonce'])) {
			$nonce = $_REQUEST['_wpnonce'];
		}

		if (wp_verify_nonce($nonce) && current_user_can('administrator')) {
			if (get_option('asseo_generate_sitemap') == true) {
				$sitemap = new Sitemap();
				$sitemap->buildSitemap();
			}
			//wp_redirect('/wp-admin/options-general.php?page=simpleSEOAdminOptions&sitemap_created=1');
			wp_redirect(admin_url('options-general.php?page=simpleSEOAdminOptions&sitemap_created=1'));
		} else {
			die(__('Failed Security Check, No no no!', ASSEO_TXTDOMAIN));
		}
	}
}

?>