<?php

namespace App\Admin\Meta;

class RedirectHandler
{

    private $table_name;

    public function __construct()
    {
        // Set the table name
        $this->table_name = $this->get_table_name();

        // Register hooks
        register_activation_hook(__FILE__, [$this, 'create_redirect_table']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_init', [$this, 'handle_delete_redirect']);
        // Add force redirection with high priority to stop page load early
        add_action('template_redirect', [$this, 'force_redirection'], 99);  // Priority 1 ensures it's high priority
    }

    /**
     * Get table name with WP prefix
     */
    private function get_table_name()
    {
        global $wpdb;
        return $wpdb->prefix . 'asseo_redirects';
    }

    /**
     * Register settings for handling redirect submissions
     */
    public function register_settings()
    {
        register_setting('asseo-settings-group', 'asseo_temp_redirect_data', [
            'sanitize_callback' => [$this, 'handle_redirect_submission']
        ]);
    }

    /**
     * Handle form submission and save redirection data
     */
    public function handle_redirect_submission($input)
    {
        if (isset($_POST['asseo_redirect_from_url'], $_POST['asseo_redirect_to_url'], $_POST['asseo_redirect_type'])) {
            global $wpdb;

            // Sanitize input
            $from_url = sanitize_text_field($_POST['asseo_redirect_from_url']);
            $to_url = sanitize_text_field($_POST['asseo_redirect_to_url']);
            $redirect_type = sanitize_text_field($_POST['asseo_redirect_type']);

            // Check if values are not empty
            if (!empty($from_url) && !empty($to_url) && !empty($redirect_type)) {

                // Check if the from_url already exists in the database
                $existing_redirect = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $this->table_name WHERE from_url = %s LIMIT 1",
                    $from_url
                ));

                if ($existing_redirect) {
                    // Optionally: update the existing record or skip insertion
                    // Uncomment the next line to update the existing record instead of skipping
                    // $wpdb->update($this->table_name, ['to_url' => $to_url, 'redirect_type' => $redirect_type], ['from_url' => $from_url]);

                    // Skip inserting duplicate
                    return $input; // Exit the function if duplicate URL exists
                }

                // Insert into the database if no duplicate is found
                $wpdb->insert(
                    $this->table_name,
                    [
                        'from_url' => $from_url,
                        'to_url' => $to_url,
                        'redirect_type' => $redirect_type,
                    ],
                    ['%s', '%s', '%s']
                );
            }
        }

        return $input;
    }

    /**
     * Handle deletion of redirects
     */
    public function handle_delete_redirect()
    {
        // Ensure this only runs when the required parameters are present
        if (!isset($_GET['page'], $_GET['delete']) || $_GET['page'] !== 'simpleSEOAdminOptions') {
            return;
        }

        // Sanitize and validate the ID parameter
        $id = intval($_GET['delete']);
        if ($id <= 0) {
            return; // Exit if the ID is not a valid positive integer
        }

        global $wpdb;

        // Perform the deletion using a prepared statement for security
        $deleted = $wpdb->delete($this->table_name, ['id' => $id], ['%d']);

        // Check if the deletion was successful
        if ($deleted === false) {
            wp_die(__('Failed to delete the redirect.', 'your-text-domain'));
        }

        // Redirect back to the admin page with a success message
        wp_redirect(admin_url('admin.php?page=simpleSEOAdminOptions&deleted=1'));
        exit;
    }


    /**
     * Force a redirection based on the request URL
     */
    public function force_redirection()
    {
        global $wpdb;

        // Get the current URL (without duplicating the base path)
        $current_url = (is_ssl() ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        // echo "<script>console.log('current_url: $current_url ');</script>";

        // $current_url = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        // echo "<script>console.log('current_url: $current_url ');</script>";

        // Query the database for the corresponding redirection
        $redirect = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM wp_asseo_redirects WHERE from_url = %s LIMIT 1",
                $current_url
            )
        );

        // Check if a redirection exists
        if ($redirect) {
            $to_url = $redirect->to_url;
            $redirect_type = $redirect->redirect_type;  
            $to_url = esc_url($to_url);  
            wp_redirect($to_url, $redirect_type);  
            exit;
        } else {
            // echo "<script>console.log('No matching redirection found.');</script>";
        }
    }



}