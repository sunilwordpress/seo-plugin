<?php

namespace app\Admin\Meta;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}

class Options
{

	public function __construct()
	{

		// if (!empty($_GET['sitemap_deleted'])) {
		// 	echo '<div class="notice notice-success is-dismissible"><p>' . __('The current sitemap has been deleted!', 'asseo-textdomain') . '</p></div>';
		// }

		// if (!empty($_GET['sitemap_created'])) {
		// 	echo '<div class="notice notice-success is-dismissible"><p>' . __('A new sitemap has been created!', 'asseo-textdomain') . '</p></div>';
		// }

		$content = '<div class="wrap" id="main-container-seo"></div>';

		$content = '<div class="wrap-more" id="main-container-seo-more">';
		$content .= '<form id="asseo-settings-form" method="post" action="options.php" novalidate>'; // Start form
		$content .= '<h1>' . __('Advanced Simple SEO Options', 'asseo-textdomain') . '</h1>';
		$content .= '<input type="hidden" name="action" value="asseo_save_redirection">';
		ob_start();
		settings_fields('asseo-settings-group'); // Ensure 'asseo-settings-group' is registered
		do_settings_sections('asseo-settings-group');
		$content .= ob_get_clean();

		$content .= '<h2 class="nav-tab-wrapper">';
		$content .= '<a href="#general" class="nav-tab nav-tab-active">' . __('General', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#meta" class="nav-tab">' . __('Meta', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#sitemap" class="nav-tab">' . __('Sitemap', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#analytics" class="nav-tab">' . __('Analytics', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#extra" class="nav-tab">' . __('Social', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#code" class="nav-tab">' . __('Code', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#crawl" class="nav-tab">' . __('Crawl', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#advanced" class="nav-tab">' . __('Advanced', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#redirection" class="nav-tab">' . __('Redirection', 'asseo-textdomain') . '</a>';
		$content .= '<a href="#tools" class="nav-tab">' . __('Tools', 'asseo-textdomain') . '</a>';
		$content .= '</h2>';

		// General Tab
		$content .= '<div class="tab-content" id="general" style="display: block;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		// Website name
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_website_name">' . __('Website Name', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_website_name" type="text" id="asseo_website_name" value="' . esc_attr(get_option('asseo_website_name')) . '" class="regular-text">';
		$pathOfHome = get_home_path() . 'wp-admin/options-general.php#blogdescription';
		$content .= '<p class="description">' . __('This field updates the ', 'asseo-textdomain') . '<a href="' . $pathOfHome . '"noopener" target="_blank">' . __('website name in your WordPress settings.', 'asseo-textdomain') . '</a></p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Tagline
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_tagline">' . __('Tagline', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_tagline" type="text" id="asseo_tagline" value="' . esc_attr(get_option('asseo_tagline')) . '" class="regular-text">';
		$pathOfHome = get_home_path() . 'wp-admin/options-general.php#blogdescription';
		$content .= '<p class="description">' . __('This field updates the ', 'asseo-textdomain') . '<a href="' . $pathOfHome . '"noopener" target="_blank">' . __('tagline in your WordPress settings.', 'asseo-textdomain') . '</a></p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Title separator
		$asseo_title_separator = get_option('asseo_title_separator');
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_title_separator">' . __('Title separator', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<select name="asseo_title_separator">';
		$content .= '<option value=""' . selected($asseo_title_separator, '', false) . '>- Select -</option>';
		$content .= '<option value="-"' . selected($asseo_title_separator, '-', false) . '>- hyphen</option>';
		$content .= '<option value="_"' . selected($asseo_title_separator, '_', false) . '>_ underscore</option>';
		$content .= '<option value=":"' . selected($asseo_title_separator, ':', false) . '>: colon</option>';
		$content .= '<option value="."' . selected($asseo_title_separator, '.', false) . '>. Dot</option>';
		$content .= '<option value="*"' . selected($asseo_title_separator, '*', false) . '>* asterisk</option>';
		$content .= '<option value="|"' . selected($asseo_title_separator, '|', false) . '>| vertical pipe</option>';
		$content .= '<option value="~"' . selected($asseo_title_separator, '~', false) . '>~ tilde</option>';
		$content .= '<option value=">"' . selected($asseo_title_separator, '>', false) . '>> greater than</option>';
		$content .= '<option value="<"' . selected($asseo_title_separator, '<', false) . '>< less than</option>';
		$content .= '</select>';
		$content .= '</td>';
		$content .= '</tr>';

		// Site image
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_site_image">' . __('Site image', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$asseo_site_image = esc_attr(get_option('asseo_site_image'));
		$content .= '<input name="asseo_site_image" type="hidden" id="asseo_site_image" value="' . $asseo_site_image . '" class="regular-text">';
		$pluginPathOfHome = get_home_url() . '/wp-content/plugins/advanced-simple-seo/assets/image-upload.png';
		$content .= '<img id="asseo_site_image_preview" src="' . ($asseo_site_image ? esc_url($asseo_site_image) : $pluginPathOfHome) . '" style="max-width:150px; display:block; margin-bottom:10px;">';
		$content .= '<button type="button" class="button" id="asseo_site_image_upload">' . __('Upload Image', 'asseo-textdomain') . '</button>';
		$content .= '<button type="button" class="button" id="asseo_site_image_remove" style="display:' . ($asseo_site_image ? 'inline-block' : 'none') . ';">' . __('Remove Image', 'asseo-textdomain') . '</button>';
		$content .= '<p class="description">' . __('This image is used as a fallback for posts/pages that don’t have any images set.', 'asseo-textdomain') . '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Meta Tab
		$content .= '<div class="tab-content" id="meta" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		// Default Meta Title
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_default_meta_title">' . __('Default Meta Title', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_default_meta_title" type="text" id="asseo_default_meta_title" value="' . esc_attr(get_option('asseo_default_meta_title')) . '" class="regular-text">';
		$content .= '<p class="description">' . __('This is the default meta title.', 'asseo-textdomain') . '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Default Meta Description
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_default_meta_description">' . __('Default Meta Description', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<textarea name="asseo_default_meta_description" rows="5" cols="50" class="large-text code">' . esc_textarea(get_option('asseo_default_meta_description')) . '</textarea>';
		$content .= '<p class="description">' . __('This is the default meta description.', 'asseo-textdomain') . '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Default Meta Keywords
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_default_meta_keywords">' . __('Default Meta Keywords', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<textarea name="asseo_default_meta_keywords" rows="2" cols="50" class="large-text code">' . esc_textarea(get_option('asseo_default_meta_keywords')) . '</textarea>';
		$content .= '<p class="description">' . __('This is the default meta keywords. <br> <em>Note: Enter a comma-separated list of your key keywords.</em>', 'asseo-textdomain') . '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Meta AI
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_ai_meta_active">' . __('AI Meta', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_ai_meta_active" name="asseo_ai_meta_active" value="1" ' . checked(get_option('asseo_ai_meta_active'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_ai_meta_active">Enable the Meta AI Generator.</label>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Meta AI API Key
		$content .= '<tr class="ai-meta-box" style="display:none;">';
		$content .= '<th scope="row"><label for="asseo_ai_meta_key">' . __('Open AI Key/Secret key', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_ai_meta_key" type="text" id="asseo_ai_meta_key" value="' . esc_attr(get_option('asseo_ai_meta_key')) . '" class="regular-text">';
		$content .= '<p class="description">' . __('Get your Open API Key <a href="https://platform.openai.com/settings/organization/api-keys" target="_blank">here</a>', 'asseo-textdomain') . '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Sitemap Tab
		$content .= '<div class="tab-content" id="sitemap" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		// Generate Sitemap
		$asseo_generate_sitemap = get_option('asseo_generate_sitemap');
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_generate_sitemap">' . __('Generate a Sitemap', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<select name="asseo_generate_sitemap">';
		$content .= '<option value="0"' . selected($asseo_generate_sitemap, 0, false) . '>No</option>';
		$content .= '<option value="1"' . selected($asseo_generate_sitemap, 1, false) . '>Yes</option>';
		$content .= '</select>';
		$pathOfHome = home_url('/') . 'sitemap.xml';
		$content .= '<p class="description">' . __('If checked, Simple SEO will generate a sitemap for your website. You must click save changes below. Your current sitemap can be seen ', 'asseo-textdomain') . '<a href="' . $pathOfHome . '"noopener" target="_blank">' . __('here.', 'asseo-textdomain') . '</a></p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Sitemap Buttons
		$adminUrlCreate = wp_nonce_url(admin_url('admin-post.php?action=asseo_create_sitemap'));
		$adminUrlDel = wp_nonce_url(admin_url('admin-post.php?action=asseo_delete_sitemap'));
		$content .= '<tr><th></th><td>';
		$content .= '<a href="' . esc_url($adminUrlCreate) . '" class="button button-primary" onclick="return confirm(\'Are you sure you want to create a new sitemap?\')">Create Sitemap</a>&nbsp;';
		$content .= '<a href="' . esc_url($adminUrlDel) . '" class="button button-primary" onclick="return confirm(\'Are you sure you want to delete the current sitemap?\')">Delete Sitemap</a>';
		$content .= '</td></tr>';
		$content .= '<tr>';
		$content .= '<th scope="row">';
		$content .= 'Sitemap Post Types';
		$content .= '</th>';
		$content .= '<td>';

		$post_types = get_post_types(['public' => true], 'names');
		$asseo_sitemap_post_types = get_option('asseo_sitemap_post_types');
		$content .= '<select name="asseo_sitemap_post_types[]" multiple>';
		if (is_array($post_types)) {
			foreach ($post_types as $post_type) {
				$selected = null;
				if (is_array($asseo_sitemap_post_types) && in_array($post_type, $asseo_sitemap_post_types)) {
					$selected = ' selected="selected"';
				}
				$content .= '<option value="' . $post_type . '"' . $selected . '>' . $post_type . '</option>';
			}
		}
		$content .= '</select>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Analytics Tab
		$content .= '<div class="tab-content" id="analytics" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		/* asseo_gsite_verification */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_gsite_verification">';
		$content .= __('Google Verification Code', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_gsite_verification" type="text" id="asseo_gsite_verification" value="' . esc_attr(get_option('asseo_gsite_verification')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= '<a href="https://support.google.com/webmasters/answer/35179?hl=en" target="_blank">';
		$content .= __('Click Here For Site Verification Code', ASSEO_TXTDOMAIN);
		$content .= '</a>';
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		/* asseo_ganalytics */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_ganalytics">';
		$content .= __('Google Analytics', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_ganalytics" type="text" id="asseo_ganalytics" value="' . esc_attr(get_option('asseo_ganalytics')) . '" class="regular-text">';
		$content .= '</td>';
		$content .= '</tr>';

		/* asseo_g4analytics */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_g4analytics">';
		$content .= __('Google Analytics 4', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_g4analytics" type="text" id="asseo_g4analytics" value="' . esc_attr(get_option('asseo_g4analytics')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= '<a href="https://support.google.com/analytics/answer/10089681?hl=en&ref_topic=9143232" target="_blank">Get Your Code</a>';
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		/* Bing verification code */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_bing">';
		$content .= __('Bing Verification Code', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_bing" type="text" id="asseo_bing" value="' . esc_attr(get_option('asseo_bing')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= '<a href="https://www.bing.com/webmasters/about#/Dashboard/" target="_blank">';
		$content .= __('Click Here To Get Your Bing Code', ASSEO_TXTDOMAIN);
		$content .= '</a>';
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		/* Yandex verification code */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_yandex">';
		$content .= __('Yandex Verification Code', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_yandex" type="text" id="asseo_yandex" value="' . esc_attr(get_option('asseo_yandex')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= '<a href="https://webmaster.yandex.com/sites/add/" target="_blank">';
		$content .= __('Click Here To Get Your Yandex Code', ASSEO_TXTDOMAIN);
		$content .= '</a>';
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		/* Baidu verification code */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_baidu">';
		$content .= __('Baidu Verification Code', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_baidu" type="text" id="asseo_baidu" value="' . esc_attr(get_option('asseo_baidu')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= '<a href="https://ziyuan.baidu.com/site" target="_blank">';
		$content .= __('Click Here To Get Your Baidu Code', ASSEO_TXTDOMAIN);
		$content .= '</a>';
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		/* Pinterest verification code */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_pinterest">';
		$content .= __('Pinterest Verification Code', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_pinterest" type="text" id="asseo_pinterest" value="' . esc_attr(get_option('asseo_pinterest')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= '<a href="https://www.pinterest.com/settings/claim" target="_blank">';
		$content .= __('Click Here To Get Your Pinterest Code', ASSEO_TXTDOMAIN);
		$content .= '</a>';
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Social Tab
		$content .= '<div class="tab-content" id="extra" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		/* Facebook verification code */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_fb_app_id">';
		$content .= __('Facebook App ID', ASSEO_TXTDOMAIN);
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_fb_app_id" type="text" id="asseo_fb_app_id" value="' . esc_attr(get_option('asseo_fb_app_id')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= '<a href="https://developers.facebook.com/docs/apps/" target="_blank">';
		$content .= __('Click Here To Get Your Facebook App ID', ASSEO_TXTDOMAIN);
		$content .= '</a>';
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		/* asseo_twitter_username */
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_twitter_username">';
		$content .= __('Twitter username');
		$content .= '</label>';
		$content .= '<td>';
		$content .= '<input name="asseo_twitter_username" type="text" id="asseo_twitter_username" value="' . esc_attr(get_option('asseo_twitter_username')) . '" class="regular-text">';
		$content .= '<p class="description">';
		$content .= __('for example @saviomdevelop');
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_fb_image">';
		$content .= __('Facebook Image');
		$content .= '</label>';
		$content .= '</th>';
		$content .= '<td>';
		$content .= '<select name="asseo_fb_image">';
		$selected = null;
		$asseo_fb_image = esc_attr(get_option('asseo_fb_image'));
		if (!empty($asseo_fb_image)) {
			$selected = ' selected="selected"';
		}
		$content .= '<option value="0"' . $selected . '>No</option>';
		$content .= '<option value="1"' . $selected . '>Yes</option>';
		$content .= '</select>';
		$content .= '<p class="description">';
		$content .= __('By default, the post featured image is used for Facebook. If no Facebook image is set, the featured image will be used.');
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';
		$content .= '<tr>';
		$content .= '<th scope="row"><label class="post-attributes-label" for="asseo_tw_image">';
		$content .= __('Twitter Image');
		$content .= '</label>';
		$content .= '</th>';
		$content .= '<td>';
		$content .= '<select name="asseo_tw_image">';
		$selected = null;
		$asseo_tw_image = esc_attr(get_option('asseo_tw_image'));
		if (!empty($asseo_tw_image)) {
			$selected = ' selected="selected"';
		}
		$content .= '<option value="0"' . $selected . '>No</option>';
		$content .= '<option value="1"' . $selected . '>Yes</option>';
		$content .= '</select>';
		$content .= '<p class="description">';
		$content .= __('By default, the post featured image is used for twitter. If no twitter image is set, the featured image will be used.');
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Code Tab
		$content .= '<div class="tab-content" id="code" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		// Header Code
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="header_code">';
		$content .= __('Header Code', ASSEO_TXTDOMAIN);
		$content .= '</label></th>';
		$content .= '<td>';
		$content .= '<textarea id="header-code" class="large-text code" rows="5" name="header_code">' . esc_textarea(get_option('header_code')) . '</textarea>';
		$content .= '<p class="description">';
		$content .= __('Code entered in this box will be printed in the <code>&lt;head&gt;</code> section.', ASSEO_TXTDOMAIN);
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Body Code
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="body_code">';
		$content .= __('Body Code', ASSEO_TXTDOMAIN);
		$content .= '</label></th>';
		$content .= '<td>';
		$content .= '<textarea id="body-code" class="large-text code" rows="5" name="body_code">' . esc_textarea(get_option('body_code')) . '</textarea>';
		$content .= '<p class="description">';
		$content .= __('Code entered in this box will be printed after the opening <code>&lt;body&gt;</code> tag.', ASSEO_TXTDOMAIN);
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';


		// Footer Code
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="footer_code">';
		$content .= __('Footer Code', ASSEO_TXTDOMAIN);
		$content .= '</label></th>';
		$content .= '<td>';
		$content .= '<textarea id="footer-code" class="large-text code" rows="5" name="footer_code">' . esc_textarea(get_option('footer_code')) . '</textarea>';
		$content .= '<p class="description">';
		$content .= __('Code entered in this box will be printed before the closing <code>&lt;/body&gt;</code> tag.', ASSEO_TXTDOMAIN);
		$content .= '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Crawl optimization Tab
		$content .= '<div class="tab-content" id="crawl" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		// Crawl Description
		$content .= '<tr>';
		$content .= '<th scope="row"><label>Remove unwanted metadata</label></th>';
		$content .= '<td>';
		$content .= '<p class="description">WordPress adds a lot of links and content to your sites <head> and HTTP headers. For most websites you can safely disable all of these, which can help to save bytes, electricity, and trees.</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove shortlinks name
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_remove_shortlinks">' . __('Remove Shortlinks', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_remove_shortlinks" name="asseo_remove_shortlinks" value="1" ' . checked(get_option('asseo_remove_shortlinks'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_remove_shortlinks">Remove links to WordPress\' internal "shortlink" URLs for your posts. <br> E.g.,</label>';
		$content .= '<code>&lt;link rel="shortlink" href="https://www.example.com/?p=1" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove REST API links
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_remove_rest_api">' . __('Remove REST API links', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_remove_rest_api" name="asseo_remove_rest_api" value="1" ' . checked(get_option('asseo_remove_rest_api'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_remove_rest_api">Remove links to the location of your site’s REST API endpoints.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="https://api.w.org/" href="https://www.example.com/wp-json/" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove RSD/WLW Links
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_remove_rsd_wlw">' . __('Remove RSD / WLW links', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_remove_rsd_wlw" name="asseo_remove_rsd_wlw" value="1" ' . checked(get_option('asseo_remove_rsd_wlw'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_remove_rsd_wlw">Remove links used by external systems for publishing content to your blog.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="EditURI" type="application/rsd+xml" href="#" /&gt;</code>';
		$content .= ' and <br><code>&lt;link rel="wlwmanifest" type="application/wlwmanifest+xml" href="#" /&gt;</code></span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove oEmbed links
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_oembed">' . __('Remove oEmbed links', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_oembed" name="asseo_oembed" value="1" ' . checked(get_option('asseo_oembed'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_oembed">Remove links used for embedding your content on other sites<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/json+oembed" href="#"/&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove generator tag
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_generator_tag">' . __('Remove Generator Tag', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_generator_tag" name="asseo_generator_tag" value="1" ' . checked(get_option('asseo_generator_tag'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_generator_tag">Remove information about the plugins and software used by your site.<br> E.g.,</label>';
		$content .= '<code>&lt;meta name="generator" content="WordPress 6.0.1"/&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove Pingback HTTP header
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_pingback_http_header">' . __('Remove Pingback HTTP Header', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_pingback_http_header" name="asseo_pingback_http_header" value="1" ' . checked(get_option('asseo_pingback_http_header'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_pingback_http_header">Remove links which allow others sites to ‘ping’ yours when they link to you. <br> E.g.,</label>';
		$content .= '<code>X-Pingback: https://www.example.com/xmlrpc.php/</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove powered by HTTP header
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_powered_by_http">' . __('Remove powered by HTTP Header', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_powered_by_http" name="asseo_powered_by_http" value="1" ' . checked(get_option('asseo_powered_by_http'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_powered_by_http">Remove links which allow others sites to ‘ping’ yours when they link to you. <br> E.g.,</label>';
		$content .= '<code>X-Powered-By: PHP/7.4.1</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Crawl Content Description
		$content .= '<tr>';
		$content .= '<th scope="row"><label>Disable unwanted content formats</label></th>';
		$content .= '<td>';
		$content .= '<p class="description">WordPress outputs your content in many different formats, across many different URLs (like RSS feeds of your posts and categories). It’s generally good practice to disable the formats you’re not actively using.</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove global feed
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_global_feed">' . __('Remove Global Feed', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_global_feed" name="asseo_global_feed" value="1" ' . checked(get_option('asseo_global_feed'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_global_feed">Remove URLs which provide an overview of your recent posts.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Example Website - Feed" href="#"/&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove global comment feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_global_comment_feed">' . __('Remove Global Comment Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_global_comment_feed" name="asseo_global_comment_feed" value="1" ' . checked(get_option('asseo_global_comment_feed'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_global_comment_feed">Remove URLs which provide an overview of recent comments on your site.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Example - Comments Feed" href="#"/&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove post comments feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_post_comment_feed">' . __('Remove Post Comments Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_post_comment_feed" name="asseo_post_comment_feed" value="1" ' . checked(get_option('asseo_post_comment_feed'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_post_comment_feed">Remove URLs which provide information about recent comments on each post. <br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Example post Comments Feed" href="#"/&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove post authors feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_post_authors_feed">' . __('Remove Post Authors Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_post_authors_feed" name="asseo_post_authors_feed" value="1" ' . checked(get_option('asseo_post_authors_feed'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_post_authors_feed">Remove URLs which provide information about recent posts by specific authors.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Example Author Feed" href="#" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove category feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_category_feed">' . __('Remove Category Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_category_feed" name="asseo_category_feed" value="1" ' . checked(get_option('asseo_category_feed'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_category_feed">Remove URLs which provide information about your recent posts, for each category.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="News Category Feed" href="#" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove tag feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_tag_feeds">' . __('Remove Tag Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_tag_feeds" name="asseo_tag_feeds" value="1" ' . checked(get_option('asseo_tag_feeds'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_tag_feeds">Remove URLs which provide information about your recent posts, for each tag.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Blue Tag Feed" href="#" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove custom taxonomy feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_taxonomy_feeds">' . __('Remove Custom Taxonomy Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_taxonomy_feeds" name="asseo_taxonomy_feeds" value="1" ' . checked(get_option('asseo_taxonomy_feeds'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_taxonomy_feeds">Remove URLs which provide information about your recent posts, for each custom taxonomy. <br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Large size Feed" href="#" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove search results feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_Search_results_feeds">' . __('Remove Search Results Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_Search_results_feeds" name="asseo_Search_results_feeds" value="1" ' . checked(get_option('asseo_Search_results_feeds'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_Search_results_feeds">Remove URLs which provide information about your search results.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Search Results for Feed" href="#" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove Atom / RDF feeds
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_atom_rdf_feeds">' . __('Remove Atom / RDF Feeds', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_atom_rdf_feeds" name="asseo_atom_rdf_feeds" value="1" ' . checked(get_option('asseo_atom_rdf_feeds'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_atom_rdf_feeds">Remove URLs which provide alternative (legacy) formats of all of the above.<br> E.g.,</label>';
		$content .= '<code>&lt;link rel="alternate" type="application/rss+xml" title="Example - Feed" href="#" /&gt;</code>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Crawl Content Description
		$content .= '<tr>';
		$content .= '<th scope="row"><label>Remove unused resources</label></th>';
		$content .= '<td>';
		$content .= '<p class="description">WordPress loads lots of resources, some of which your site might not need. If you’re not using these, removing them can speed up your pages and save resources.</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove emoji scripts
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_emoji_scripts">' . __('Remove Emoji Scripts', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_emoji_scripts" name="asseo_emoji_scripts" value="1" ' . checked(get_option('asseo_emoji_scripts'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_emoji_scripts">Remove JavaScript used for converting emoji characters in older browsers.</label>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Remove WP-JSON API
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_wpjson_api">' . __('Remove WP-JSON API', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_wpjson_api" name="asseo_wpjson_api" value="1" ' . checked(get_option('asseo_wpjson_api'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_wpjson_api">Add a ‘disallow’ rule to your robots.txt file to prevent crawling of WordPress JSON API endpoints.</label></span>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Advanced Tab
		$content .= '<div class="tab-content" id="advanced" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		// breadcrumbs
		$content .= '<tr>';
		$content .= '<th scope="row"><label>Breadcrumb Appearance</label></th>';
		$content .= '<td>';
		$content .= '<p class="description">Choose the general appearance of your breadcrumbs.</p>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_breadcrumbs_active">' . __('Show blog/page in breadcrumbs', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input type="checkbox" id="asseo_breadcrumbs_active" name="asseo_breadcrumbs_active" value="1" ' . checked(get_option('asseo_breadcrumbs_active'), 1, false) . ' class="styled-checkbox">';
		$content .= '<span class="description-label"><label for="asseo_breadcrumbs_active">Enable the breadcrumbs. use this shortcode <code>[asseo_breadcrumbs]</code></label>';
		$content .= '</span>';
		$content .= '</td>';
		$content .= '</tr>';

		// Separator between breadcrumbs
		$content .= '<tr class="tab-content-inner-box" style=display:none;>';
		$content .= '<th scope="row"><label for="asseo_between_breadcrumbs">' . __('Separator between breadcrumbs', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_between_breadcrumbs" type="text" id="asseo_between_breadcrumbs" value="' . esc_attr(get_option('asseo_between_breadcrumbs')) . '" class="regular-text">';
		$content .= '</td>';
		$content .= '</tr>';

		// Anchor text for the Homepage
		$content .= '<tr class="tab-content-inner-box"  style=display:none;>';
		$content .= '<th scope="row"><label for="asseo_anchor_text">' . __('Anchor text for the Homepage', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_anchor_text" type="text" id="asseo_anchor_text" value="' . esc_attr(get_option('asseo_anchor_text')) . '" class="regular-text">';
		$content .= '</td>';
		$content .= '</tr>';

		// Prefix for the breadcrumb path
		$content .= '<tr class="tab-content-inner-box"  style=display:none;>';
		$content .= '<th scope="row"><label for="asseo_prefix_breadcrumb_path">' . __('Prefix for the breadcrumb path', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_prefix_breadcrumb_path" type="text" id="asseo_prefix_breadcrumb_path" value="' . esc_attr(get_option('asseo_prefix_breadcrumb_path')) . '" class="regular-text">';
		$content .= '</td>';
		$content .= '</tr>';

		// Site Representation
		$content .= '<tr>';
		$content .= '<th scope="row"><label>Site Representation</label></th>';
		$content .= '<td>';
		$content .= '<p class="description">This info is intended to appear in Googles Knowledge Graph.</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Organization/Person
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_organization_person">' . __('Organization/Person', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		// Radio button for none
		$content .= '<input type="radio" id="asseo_none" name="asseo_none" value="none" ' . checked(get_option('asseo_none'), 'none', false) . ' class="styled-radio">';
		$content .= '<span class="description-label"><label for="asseo_none">None</label></span><br>';
		// Radio button for Organization
		$content .= '<input type="radio" id="asseo_organization" name="asseo_organization" value="organization" ' . checked(get_option('asseo_organization'), 'organization', false) . ' class="styled-radio">';
		$content .= '<span class="description-label"><label for="asseo_organization">Organization</label></span><br>';
		// Radio button for Person
		$content .= '<input type="radio" id="asseo_person" name="asseo_person" value="person" ' . checked(get_option('asseo_person'), 'person', false) . ' class="styled-radio">';
		$content .= '<span class="description-label"><label for="asseo_person">Person</label></span><br>';
		// Description
		$content .= '<span class="description-label"><label for="asseo_organization_person">Choose whether your site represents an organization or a person.</label></span>';
		$content .= '</td>';
		$content .= '</tr>';


		// Organization Name
		$content .= '<tr class="org_organization-inner-box" style="display:none;">';
		$content .= '<th scope="row"><label for="asseo_organization_name">' . __('Organization Name', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_organization_name" type="text" id="asseo_organization_name" value="' . esc_attr(get_option('asseo_organization_name')) . '" class="regular-text">';
		$content .= '</td>';
		$content .= '</tr>';

		// Organization logo
		$content .= '<tr class="org_organization-inner-box" style="display:none;">';
		$content .= '<th scope="row"><label for="asseo_organization_logo">' . __('Organization Logo', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$asseo_organization_logo = esc_attr(get_option('asseo_organization_logo'));
		$content .= '<input name="asseo_organization_logo" type="hidden" id="asseo_organization_logo" value="' . $asseo_organization_logo . '" class="regular-text">';
		$pluginPathOfHome = get_home_url() . '/wp-content/plugins/advanced-simple-seo/assets/image-upload.png';
		$content .= '<img id="asseo_organization_logo_preview" src="' . ($asseo_organization_logo ? esc_url($asseo_organization_logo) : $pluginPathOfHome) . '" style="max-width:150px; display:block; margin-bottom:10px;">';
		$content .= '<button type="button" class="button" id="asseo_organization_logo_upload">' . __('Upload Image', 'asseo-textdomain') . '</button>';
		$content .= '<button type="button" class="button" id="asseo_organization_logo_remove" style="display:' . ($asseo_organization_logo ? 'inline-block' : 'none') . ';">' . __('Remove Image', 'asseo-textdomain') . '</button>';
		$content .= '</td>';
		$content .= '</tr>';

		// Personal info
		$content .= '<tr class="org_person-inner-box" style="display:none;">';
		$content .= '<th scope="row"><label for="asseo_person_name">' . __('Select a User', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$users = get_users();
		$content .= '<select name="asseo_users" id="asseo_users">';
		foreach ($users as $user) {
			// Check if the user is selected
			$selected = (get_option('asseo_users') == $user->ID) ? 'selected' : '';
			$content .= '<option value="' . esc_attr($user->ID) . '" ' . $selected . '>' . esc_html($user->display_name) . '</option>';
		}
		$content .= '</select>';
		$content .= '</td>';
		$content .= '</tr>';


		// Personal logo
		$content .= '<tr class="org_person-inner-box" style="display:none;">';
		$content .= '<th scope="row"><label for="asseo_person_logo">' . __('Personal logo or avatar', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$asseo_person_logo = esc_attr(get_option('asseo_person_logo'));
		$content .= '<input name="asseo_person_logo" type="hidden" id="asseo_person_logo" value="' . $asseo_person_logo . '" class="regular-text">';
		$pluginPathOfHome = get_home_url() . '/wp-content/plugins/advanced-simple-seo/assets/image-upload.png';
		$content .= '<img id="asseo_person_logo_preview" src="' . ($asseo_person_logo ? esc_url($asseo_person_logo) : $pluginPathOfHome) . '" style="max-width:150px; display:block; margin-bottom:10px;">';
		$content .= '<button type="button" class="button" id="asseo_person_logo_upload">' . __('Upload Image', 'asseo-textdomain') . '</button>';
		$content .= '<button type="button" class="button" id="asseo_person_logo_remove" style="display:' . ($asseo_person_logo ? 'inline-block' : 'none') . ';">' . __('Remove Image', 'asseo-textdomain') . '</button>';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Submit Button
		$content .= '<input type="submit" name="submit" id="submit" class="button button-primary submit-btn" value="' . __('Save Changes', 'asseo-textdomain') . '">';
		$content .= '</form>'; // End form
		$content .= '<br><label class="notice-form"></label>';

		///////////////////////////
		
		// redirection Tab
		$content .= '<div class="tab-content" id="redirection" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';
		
		$content .= '<form method="post" action="" novalidate>';
		// From URL
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_redirect_from_url">' . __(
			'From URL',
			'asseo-textdomain'
		) . '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_redirect_from_url" type="text" id="asseo_redirect_from_url"
							value="" class="regular-text">';
		$content .= '<p class="description">' . __('Enter the URL to redirect from (relative to site
							URL).', 'asseo-textdomain') . '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// To URL
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_redirect_to_url">' . __('To URL', 'asseo-textdomain')
			. '</label></th>';
		$content .= '<td>';
		$content .= '<input name="asseo_redirect_to_url" type="text" id="asseo_redirect_to_url" value=""
				class="regular-text">';
		$content .= '<p class="description">' . __(
			'Enter the destination URL (absolute or relative).',
			'asseo-textdomain'
		) . '</p>';
		$content .= '</td>';
		$content .= '</tr>';

		// Redirection Type (your provided HTML)
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_redirect_type">' . __(
			'Redirection Type',
			'asseo-textdomain'
		) . '</label></th>';
		$content .= '<td>';
		$content .= '<select name="asseo_redirect_type" id="asseo_redirect_type">';
		$content .= '<option value="301">' . __('301 - Permanent', 'asseo-textdomain') . '</option>
				';
		$content .= '<option value="302">' . __('302 - Temporary', 'asseo-textdomain') . '</option>
				';
		$content .= '</select>';
		$content .= '<p class="description">' . __(
			'Choose the type of redirection.',
			'asseo-textdomain'
		) . '</p>';
		$content .= '<button type="button" id="add_redirect_button" class="common-btn">' . __('Add Redirect', 'asseo-textdomain') . '</button>';

		$content .= '</td>';
		$content .= '</tr>';

		// Display Existing Redirects
		$content .= '<h2>' . __('Existing Redirects', 'asseo-textdomain') . '</h2>';
		$content .= '<table class="wp-list-table widefat fixed striped">';
		$content .= '<thead>
				<tr>';
		$content .= '<th>' . __('From URL', 'asseo-textdomain') . '</th>';
		$content .= '<th>' . __('To URL', 'asseo-textdomain') . '</th>';
		$content .= '<th>' . __('Type', 'asseo-textdomain') . '</th>';
		$content .= '<th>' . __('Actions', 'asseo-textdomain') . '</th>';
		$content .= '</tr>
			</thead>';
		$content .= '<tbody>';

		global $wpdb;
		$table_name = $wpdb->prefix . 'asseo_redirects';
		$redirects = $wpdb->get_results("SELECT * FROM $table_name");

		// Use your existing code to display the table
		if ($redirects) {
			foreach ($redirects as $redirect) {
				$content .= '<tr>';
				$content .= '<td>' . esc_html($redirect->from_url) . '</td>';
				$content .= '<td>' . esc_html($redirect->to_url) . '</td>';
				$content .= '<td>' . esc_html($redirect->redirect_type) . '</td>';
				$content .= '<td><a href="#" class="delete-redirect" data-id="' . esc_attr($redirect->id) . '" style="color: red; border: 1px solid; padding: 2px 10px; border-radius: 2px; text-decoration: none; line-height: normal; vertical-align: middle; display: initial;">Delete</a></td>';
				$content .= '</tr>';

			}
		} else {
			$content .= '<tr><td colspan="4">' . __('No redirects found.', 'asseo-textdomain') . '</td></tr>';
		}
		$content .= '</form>';

		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		// Tools Tab
		$content .= '<div class="tab-content" id="tools" style="display: none;">';
		$content .= '<table class="form-table">';
		$content .= '<tbody>';

		// Bulk Editor Section
		$content .= '<h2>' . __('Bulk Editor', 'asseo-textdomain') . '</h2>';
		$content .= '<div class="bulk-editor">';
		$content .= '<p class="description">' . __('A Post/Page Bulk Editor allows you to edit multiple posts, pages, or custom post types simultaneously.', 'asseo-textdomain') . '</p>';
		$content .= '<a href="' . admin_url('admin.php?page=bulkEditorPage') . '" class="common-btn">Go to Bulk Editor</a>&nbsp;';
		$content .= '</div><br>';

		// Import and Export Section
		$content .= '<h2>' . __('Import/Export Settings (json format)', 'asseo-textdomain') . '</h2>';
		$content .= '<div class="importExport">';
		$content .= '<form method="post" action="" enctype="multipart/form-data">';
		$content .= '<input type="file" name="asseo_import_file" accept=".json">';
		$content .= '<input type="submit" name="asseo_import_settings" class="import-btn" value="' . __('Import Settings', 'asseo-textdomain') . '">';
		$content .= '</form>';
		$content .= '<form method="post" action="">';
		$content .= '<input type="submit" name="asseo_export_settings" class="export-btn" value="' . __('Export Settings', 'asseo-textdomain') . '">';
		$content .= '</form>';
		$content .= '</div><br>';


		// Fetch robots.txt content (if exists)
		$content .= '<h2>' . __('File Editor', 'asseo-textdomain') . '</h2>';
		$robots_content = asseo_get_robots_content();
		$content .= '<form method="post" action="" novalidate>';
		$content .= '<input type="hidden" name="action" value="asseo_save_robots">';

		// Textarea for robots.txt content
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_robots_field">' . __('Edit robots.txt Content', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<textarea name="asseo_robots_field" id="asseo_robots_field" class="large-text code" rows="10">' . esc_textarea($robots_content) . '</textarea>';
		$content .= '<p class="description">' . __('Modify the content of your robots.txt file. Save changes to update the file.', 'asseo-textdomain') . '</p>';
		$content .= '<br><input type="submit" class="button button-primary common-btn" value="' . __('Save Changes for robots.txt', 'asseo-textdomain') . '">';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</form>';

		$content .= '<div class="htaccessManagement">';

		$content .= '<form method="post" action="" novalidate>';
		$content .= '<input type="hidden" name="action" value="asseo_save_htaccess">';

		// Fetch .htaccess content (if exists)
		$htaccess_content = asseo_get_htaccess_content();

		// Textarea for .htaccess content
		$content .= '<tr>';
		$content .= '<th scope="row"><label for="asseo_htaccess_field">' . __('Edit .htaccess Content', 'asseo-textdomain') . '</label></th>';
		$content .= '<td>';
		$content .= '<textarea name="asseo_htaccess_field" id="asseo_htaccess_field" class="large-text code" rows="10">' . esc_textarea($htaccess_content) . '</textarea>';
		$content .= '<p class="description">' . __('Modify the content of your .htaccess file. Save changes to update the file.', 'asseo-textdomain') . '</p>';
		$content .= '<br><input type="submit" class="button button-primary common-btn" value="' . __('Save Changes for .htaccess', 'asseo-textdomain') . '">';
		$content .= '</td>';
		$content .= '</tr>';

		$content .= '</form>';
		$content .= '</div>';


		$content .= '</tbody>';
		$content .= '</table>';
		$content .= '</div>';

		

		// JavaScript for tabs and others

		$content .= '<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
					<script>
					document.addEventListener("DOMContentLoaded", function() {
						const tabs = document.querySelectorAll(".nav-tab");
						const tabContents = document.querySelectorAll(".tab-content");
						tabs.forEach(tab => {
							tab.addEventListener("click", function(e) {
								e.preventDefault();
								tabs.forEach(t => t.classList.remove("nav-tab-active"));
								this.classList.add("nav-tab-active");
								tabContents.forEach(tc => tc.style.display = "none");
								document.querySelector(this.getAttribute("href")).style.display = "block";
							});
						});
					});
					</script>';

		$content .= '<script>
						document.addEventListener("DOMContentLoaded", function () {
							var breadcrumbsCheckbox = document.getElementById("asseo_breadcrumbs_active");
							var innerBoxRows = document.querySelectorAll(".tab-content-inner-box");
							function toggleBreadcrumbContent() {
								innerBoxRows.forEach(function (row) {
									if (breadcrumbsCheckbox.checked) {
										row.style.display = "table-row";
									} else {
										row.style.display = "none";
									}
								});								
							}
							toggleBreadcrumbContent();
							breadcrumbsCheckbox.addEventListener("change", toggleBreadcrumbContent);
						});

						document.addEventListener("DOMContentLoaded", function () {
							const checkbox = document.getElementById("asseo_ai_meta_active");
							const metaBox = document.querySelector(".ai-meta-box");
							function toggleMetaBox() {
								if (checkbox.checked) {
									metaBox.style.display = "";
								} else {
									metaBox.style.display = "none";
								}
							}
							toggleMetaBox();
							checkbox.addEventListener("change", toggleMetaBox);
						});
					</script>';

		$content .= '<script>
						document.addEventListener("DOMContentLoaded", function () {
							var noneRadio = document.getElementById("asseo_none");
							var organizationRadio = document.getElementById("asseo_organization");
							var personRadio = document.getElementById("asseo_person");
							var organizationFields = document.querySelectorAll(".org_organization-inner-box");
							var personFields = document.querySelectorAll(".org_person-inner-box");
							function toggleFields(selectedRadio) {
								if (selectedRadio === "organization") {
									organizationRadio.checked = true;
									personRadio.checked = false;
									noneRadio.checked = false;
									organizationFields.forEach(function (field) {
										field.style.display = "table-row";
									});
									personFields.forEach(function (field) {
										field.style.display = "none";
									});
								} else if (selectedRadio === "person") {
									// Select the Person radio and deselect the others
									personRadio.checked = true;
									organizationRadio.checked = false;
									noneRadio.checked = false;

									// Show Person fields
									personFields.forEach(function (field) {
										field.style.display = "table-row";
									});

									// Hide Organization fields
									organizationFields.forEach(function (field) {
										field.style.display = "none";
									});
								} else if (selectedRadio === "none") {
									// Deselect all radios
									noneRadio.checked = true;
									organizationRadio.checked = false;
									personRadio.checked = false;

									// Hide both Organization and Person fields
									organizationFields.forEach(function (field) {
										field.style.display = "none";
									});
									personFields.forEach(function (field) {
										field.style.display = "none";
									});
								}
							}

							// Event listeners for the radio buttons
							noneRadio.addEventListener("change", function () {
								toggleFields("none");
							});

							organizationRadio.addEventListener("change", function () {
								toggleFields("organization");
							});

							personRadio.addEventListener("change", function () {
								toggleFields("person");
							});

							// Initialize the correct state on page load
							if (noneRadio.checked) {
								toggleFields("none");
							} else if (organizationRadio.checked) {
								toggleFields("organization");
							} else if (personRadio.checked) {
								toggleFields("person");
							}
						});
					</script>';

		echo $content;

	}
}

?>