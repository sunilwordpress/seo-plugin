<?php

namespace App\Admin\Meta;

class GeneralTabHandler
{
    public function __construct()
    {
        add_action('admin_init', [$this, 'save_website_name_to_site_title']);
        add_action('admin_init', [$this, 'save_tagline_to_site']);

        // Hook to save the 'asseo_title_separator' value when settings are saved
        add_action('admin_init', [$this, 'save_title_separator']);

        // Initialize the plugin settings if needed, to pre-populate the 'asseo_title_separator' value
        add_action('admin_init', [$this, 'initialize_title_separator']);

        // Modify the site title based on the selected separator
        add_filter('document_title_parts', [$this, 'modify_title_with_separator'], 20);

        // Hook to save the asseo_site_image value when the form is submitted
        add_action('admin_init', [$this, 'save_site_image']);

        // Hook to set fallback image for posts/pages without a featured image
        add_filter('post_thumbnail_html', [$this, 'set_fallback_image_html'], 10, 5);

        // Hook to set fallback image for wp_get_attachment_image_src
        add_filter('wp_get_attachment_image_src', [$this, 'set_fallback_image_src'], 10, 4);

        // Hook to replace the site image when the featured image is missing
        add_filter('get_post_metadata', [$this, 'replace_missing_featured_image'], 10, 4);
    }

    public function save_website_name_to_site_title()
    {
        if (isset($_POST['asseo_website_name']) && !empty($_POST['asseo_website_name'])) {
            $website_name = sanitize_text_field($_POST['asseo_website_name']);
            update_option('blogname', $website_name);
        }
    }

    public function save_tagline_to_site()
    {
        if (isset($_POST['asseo_tagline']) && !empty($_POST['asseo_tagline'])) {
            $website_name = sanitize_text_field($_POST['asseo_tagline']);
            update_option('blogdescription', $website_name);
        }
    }

    public function initialize_title_separator()
    {
        if (false === get_option('asseo_title_separator')) {
            update_option('asseo_title_separator', '-');
        }
    }

    public function save_title_separator()
    {
        if (isset($_POST['asseo_title_separator']) && !empty($_POST['asseo_title_separator'])) {
            $title_separator = sanitize_text_field($_POST['asseo_title_separator']);
            update_option('asseo_title_separator', $title_separator);
        }
    }

    public function modify_title_with_separator($title_parts)
    {
        $separator = get_option('asseo_title_separator', '-');

        if (!empty($separator) && trim($separator) !== '') {
            if (isset($title_parts['site'])) {
                $title_parts['title'] = $title_parts['title'] . ' ' . trim($separator) . ' ' . $title_parts['site'];
            } else {
                $site_name = get_bloginfo('name');
                $title_parts['title'] = $title_parts['title'] . ' ' . trim($separator) . ' ' . $site_name;
            }
        }

        return $title_parts;
    }



    public function save_site_image()
    {
        if (isset($_POST['asseo_site_image'])) {
            $site_image_url = esc_url_raw($_POST['asseo_site_image']);
            update_option('asseo_site_image', $site_image_url);
        }
    }

    public function set_fallback_image_html($html, $post_id, $post_thumbnail_id, $size, $attr)
    {
        if (empty($html)) {
            $fallback_image = get_option('asseo_site_image');
            if ($fallback_image) {
                $html = '<img src="' . esc_url($fallback_image) . '" alt="' . esc_attr__('Fallback Image', 'asseo-textdomain') . '" class="fallback-featured-image">';
            }
        }

        return $html;
    }

    public function set_fallback_image_src($image, $attachment_id, $size, $icon)
    {
        if (empty($image)) {
            $fallback_image = get_option('asseo_site_image');
            if ($fallback_image) {
                $image = [
                    esc_url($fallback_image),
                    150,
                    150,
                    false
                ];
            }
        }

        return $image;
    }

    public function replace_missing_featured_image($metadata, $object_id, $meta_key, $single)
    {
        if ($meta_key === '_thumbnail_id') {
            $post_type = get_post_type($object_id);
            $fallback_image = get_option('asseo_site_image');

            if (!empty($fallback_image) && empty($metadata)) {
                // Check if the site image is already uploaded as an attachment
                $attachment_id = $this->get_site_image_attachment_id($fallback_image);
                if (!$attachment_id) {
                    $attachment_id = $this->create_attachment_for_image($fallback_image);
                }

                if ($attachment_id) {
                    return $attachment_id;
                }
            }
        }

        return $metadata;
    }

    private function create_attachment_for_image($image_url)
    {
        $upload_dir = wp_upload_dir();
        $filename = basename($image_url);

        // Check if the file already exists in the uploads directory
        $file_path = $upload_dir['path'] . '/' . $filename;
        if (!file_exists($file_path)) {
            $image_data = file_get_contents($image_url);
            if ($image_data) {
                file_put_contents($file_path, $image_data);
            }
        }

        // Check if the image already exists as an attachment
        $attachment_id = $this->get_site_image_attachment_id($image_url);
        if ($attachment_id) {
            return $attachment_id;
        }

        // Create a new attachment if it doesn't exist
        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = [
            'post_mime_type' => $wp_filetype['type'],
            'post_title' => sanitize_file_name($filename),
            'post_content' => '',
            'post_status' => 'inherit'
        ];

        $attachment_id = wp_insert_attachment($attachment, $file_path);
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attach_data = wp_generate_attachment_metadata($attachment_id, $file_path);
        wp_update_attachment_metadata($attachment_id, $attach_data);

        return $attachment_id;
    }

    private function get_site_image_attachment_id($image_url)
    {
        global $wpdb;
        $upload_dir = wp_upload_dir();
        $filename = basename($image_url);

        // Search for the attachment by file name
        $query = $wpdb->prepare(
            "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND guid LIKE %s LIMIT 1",
            '%' . $wpdb->esc_like($filename) . '%'
        );

        return $wpdb->get_var($query);
    }

}
