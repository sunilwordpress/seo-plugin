<?php
// Handle the robots.txt file form submission
function asseo_handle_robots_form_submission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'asseo_save_robots') {

        // Check user capability
        if (!current_user_can('manage_options')) {
            return;
        }

        // Sanitize the input
        $robots_content = isset($_POST['asseo_robots_field']) ? sanitize_textarea_field($_POST['asseo_robots_field']) : '';

        // Define the path for robots.txt
        $robots_file = ABSPATH . 'robots.txt';

        if (!empty($robots_content)) {
            // Save content to robots.txt file
            file_put_contents($robots_file, $robots_content);
            update_option('asseo_robots_field', $robots_content);
        } else {
            // If the field is empty, delete the file or remove the option
            if (file_exists($robots_file)) {
                unlink($robots_file);
            }
            delete_option('asseo_robots_field');
        }

        // Success message
        add_action('admin_notices', function () {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Robots.txt file has been updated successfully.', 'asseo-textdomain') . '</p></div>';
        });
    }
}
add_action('admin_init', 'asseo_handle_robots_form_submission');

// Fetch robots.txt content
function asseo_get_robots_content() {
    $robots_file = ABSPATH . 'robots.txt';
    if (file_exists($robots_file)) {
        return file_get_contents($robots_file);
    }
    return get_option('asseo_robots_field', "User-agent: *\nDisallow:");
}

// Handle the .htaccess file form submission
function asseo_handle_htaccess_form_submission() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'asseo_save_htaccess') {

        // Check user capability
        if (!current_user_can('manage_options')) {
            return;
        }

        // Sanitize the input
        $htaccess_content = isset($_POST['asseo_htaccess_field']) ? sanitize_textarea_field($_POST['asseo_htaccess_field']) : '';

        // Define the path for .htaccess
        $htaccess_file = ABSPATH . '.htaccess';

        if (!empty($htaccess_content)) {
            // Save content to .htaccess file
            file_put_contents($htaccess_file, $htaccess_content);
            update_option('asseo_htaccess_field', $htaccess_content);
        } else {
            // If the field is empty, delete the file or remove the option
            if (file_exists($htaccess_file)) {
                unlink($htaccess_file);
            }
            delete_option('asseo_htaccess_field');
        }

        // Success message
        add_action('admin_notices', function () {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('.htaccess file has been updated successfully.', 'asseo-textdomain') . '</p></div>';
        });
    }
}
add_action('admin_init', 'asseo_handle_htaccess_form_submission');

// Fetch .htaccess content
function asseo_get_htaccess_content() {
    $htaccess_file = ABSPATH . '.htaccess';
    if (file_exists($htaccess_file)) {
        return file_get_contents($htaccess_file);
    }
    return get_option('asseo_htaccess_field', "# Default .htaccess file content\n");
}
