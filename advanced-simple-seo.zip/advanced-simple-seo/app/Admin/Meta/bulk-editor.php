<?php
// Display Bulk Editor page
function display_bulk_editor_page() {
    // Check for user permissions
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.'));
    }

    // Number of posts per page
    $posts_per_page = 10;

    // Get current page number from the query string
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;

    // Query to fetch posts/pages with pagination
    $query_args = [
        'post_type'      => ['post', 'page'], // Fetch both posts and pages
        'posts_per_page' => $posts_per_page,
        'paged'          => $current_page,
        'post_status'    => 'any',
    ];

    $bulk_query = new WP_Query($query_args);

    echo '<div class="wrap" id="main-container-seo-more">';
    echo '<h1>' . __('Bulk Editor', 'simpleseo-textdomain') . '</h1>';

    // Start Table
    echo '<table class="widefat fixed" cellspacing="0">';
    echo '<thead>
            <tr class="header-tr">
                <th class="th-id">ID</th>
                <th class="th-title">Title</th>
                <th>Content Type</th>
                <th>Status</th>
                <th>Meta Title</th>
                <th>Meta Description</th>
                <th>Action</th>
            </tr>
          </thead>';
    echo '<tbody>';

    // Check if there are posts/pages
    if ($bulk_query->have_posts()) {
        while ($bulk_query->have_posts()) {
            $bulk_query->the_post();
            $post_id       = get_the_ID();
            $post_title    = get_the_title();
            $post_type     = get_post_type();
            $post_status   = get_post_status();
            $meta_title    = get_post_meta($post_id, 'asseo_meta_title', true);
            $meta_desc     = get_post_meta($post_id, 'asseoMetaDescription', true);

            // Table row for each post/page
            echo '<form method="post" action="">'; // Add form for each row
            echo '<tr>';
            echo '<td>' . esc_html($post_id) . '</td>';
            echo '<td>' . esc_html($post_title) . '</td>';
            echo '<td>' . esc_html(ucfirst($post_type)) . '</td>';
            echo '<td>' . esc_html(ucfirst($post_status)) . '</td>';
            echo '<td>
                    <input type="text" name="meta_title" value="' . esc_attr($meta_title) . '" size="30">
                  </td>';
            echo '<td>
                    <textarea name="meta_desc" rows="2" style="width: 100%;">' . esc_textarea($meta_desc) . '</textarea>
                  </td>';
            echo '<td>
                    <input type="hidden" name="post_id" value="' . esc_attr($post_id) . '">
                    <input type="submit" name="save_meta" class="common-btn" value="Save">
                  </td>';
            echo '</tr>';
            echo '</form>'; // Close form for this row
        }
    } else {
        echo '<tr><td colspan="7">' . __('No posts or pages found.', 'simpleseo-textdomain') . '</td></tr>';
    }

    echo '</tbody>';
    echo '</table>';

    // Pagination Links
    $total_pages = $bulk_query->max_num_pages;

    if ($total_pages > 1) {
        echo '<div class="tablenav"><div class="tablenavi">';
        echo paginate_links([
            'base'      => add_query_arg('paged', '%#%'),
            'format'    => '',
            'current'   => $current_page,
            'total'     => $total_pages,
            'prev_text' => __('&laquo; Previous'),
            'next_text' => __('Next &raquo;'),
        ]);
        echo '</div></div>';
    }

    echo '</div>';

    // Reset Post Data
    wp_reset_postdata();
}

// Add Bulk Editor menu page
add_action('admin_menu', function() {
    add_menu_page(
        __('Bulk Editor', 'simpleseo-textdomain'), // Page Title
        __('Bulk Editor', 'simpleseo-textdomain'), // Menu Title
        'manage_options', // Capability (only admins can access)
        'bulkEditorPage', // Page slug
        'display_bulk_editor_page', // Callback function
        '', // Icon (optional)
        20 // Position in menu (optional)
    );
});

// Handle Saving Meta Fields
function handle_bulk_editor_save() {
    if (isset($_POST['save_meta']) && isset($_POST['post_id'])) {
        $post_id = intval($_POST['post_id']);

        // Security check
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Save meta title and description
        if (isset($_POST['meta_title'])) {
            update_post_meta($post_id, 'asseo_meta_title', sanitize_text_field($_POST['meta_title']));
        }
        if (isset($_POST['meta_desc'])) {
            update_post_meta($post_id, 'asseoMetaDescription', sanitize_textarea_field($_POST['meta_desc']));
        }

        // Display admin notice
        add_action('admin_notices', function () {
            echo '<div class="notice notice-success is-dismissible"><p>' . __('Meta fields updated successfully.', 'simpleseo-textdomain') . '</p></div>';
        });
    }
}
add_action('admin_init', 'handle_bulk_editor_save');
