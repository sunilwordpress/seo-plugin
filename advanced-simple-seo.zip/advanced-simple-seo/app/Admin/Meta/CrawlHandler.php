<?php

namespace App\Admin\Meta;

class CrawlHandler
{
    public function __construct()
    {
        // Hook into WordPress to handle the removal of shortlinks
        add_action('wp', [$this, 'remove_shortlinks']);
        add_action('wp', [$this, 'remove_shortlink_from_output']);
        add_filter('pre_get_shortlink', [$this, 'disable_shortlink'], 10, 2);

        // Hook into WordPress to handle the removal of REST API links
        add_action('init', [$this, 'remove_rest_api_links']);

        // Hook into WordPress to handle the removal of RSD/WLW links
        add_action('wp', [$this, 'buffer_and_remove_links']);

        // Hook to remove oEmbed links if the setting is enabled
        add_action('init', [$this, 'remove_oembed_links']);

        // Hook to remove the generator tag by starting output buffering
        add_action('init', [$this, 'remove_generator_tag']);

        // Hook to remove the Pingback HTTP header if the option is enabled
        add_action('init', [$this, 'remove_pingback_http_header']);

        // Hook to remove the remove_powered_by HTTP header if the option is enabled
        add_action('init', [$this, 'remove_powered_by_http']);

        // Hook into WordPress to handle various removals
        add_action('wp_head', [$this, 'remove_global_feed'], 10);

        // Hook into WordPress to handle various removals
        add_action('wp_head', [$this, 'remove_global_comment_feed'], 10);

        // Hook into WordPress to handle removal of post comment feeds
        add_action('wp_head', [$this, 'remove_post_comment_feed'], 10);

        // Hook into WordPress to handle removal of post author feeds
        add_action('wp_head', [$this, 'remove_post_authors_feed'], 10);

        // Hook into WordPress to handle removal of category feeds
        add_action('wp_head', [$this, 'remove_category_feed'], 10);

        // Hook into WordPress to handle removal of tag feeds
        add_action('wp_head', [$this, 'remove_tag_feed'], 10);

        // Hook into WordPress to handle removal of custom taxonomy feeds
        add_action('wp_head', [$this, 'remove_custom_taxonomy_feed'], 10);

        // Hook into WordPress to handle removal of search results feeds
        add_action('wp_head', [$this, 'remove_search_results_feed'], 10);

        // Hook into WordPress to handle removal of Atom / RDF feeds
        add_action('wp_head', [$this, 'remove_atom_rdf_feeds'], 10);

        // Hook into WordPress to handle the removal of emoji scripts
        add_action('wp_head', [$this, 'remove_emoji_scripts'], 1);
        add_action('wp_print_scripts', [$this, 'remove_emoji_scripts_from_footer'], 100);

        // Hook to check and modify the robots.txt file
        add_action('robots_txt', [$this, 'add_robots_txt_rules'], 10, 2);

    }

    /**
     * Remove shortlinks from the wp_head
     */
    public function remove_shortlinks()
    {
        if (get_option('asseo_remove_shortlinks') == 1) {
            remove_action('wp_head', 'wp_shortlink_wp_head', 10);
            add_filter('pre_get_shortlink', '__return_empty_string');
        }
    }

    /**
     * Remove shortlink from the final HTML output
     */
    public function remove_shortlink_from_output()
    {
        if (get_option('asseo_remove_shortlinks') == 1) {
            ob_start(function ($buffer) {
                return preg_replace('/<link rel="shortlink" [^>]+>/', '', $buffer);
            });
        }
    }

    /**
     * Disable the shortlink URL generation
     *
     * @param string $shortlink
     * @param int|null $id
     * @return string
     */
    public function disable_shortlink($shortlink, $id)
    {
        if (get_option('asseo_remove_shortlinks') == 1) {
            return '';
        }
        return $shortlink;
    }

    /**
     * Remove REST API links from the wp_head and headers
     */
    public function remove_rest_api_links()
    {
        if (get_option('asseo_remove_rest_api') == 1) {
            remove_action('wp_head', 'rest_output_link_wp_head', 20);
            remove_action('template_redirect', 'rest_output_link_header', 11, 0);
            remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
            add_filter('rest_url', [$this, 'disable_rest_api_links'], 10, 2);
        }
    }

    /**
     * Disable REST API URL generation.
     *
     * @param string $url
     * @param string $path 
     * @return string 
     */
    public function disable_rest_api_links($url, $path)
    {
        return '';
    }


    /**
     * Start output buffering and remove the RSD/WLW links
     */
    public function buffer_and_remove_links()
    {
        if (get_option('asseo_remove_rsd_wlw') == 1) {
            ob_start(function ($buffer) {
                $buffer = preg_replace('/<link rel="EditURI" [^>]+>/', '', $buffer);
                $buffer = preg_replace('/<link rel="wlwmanifest" [^>]+>/', '', $buffer);

                return $buffer;
            });
        }
    }

    /**
     * Remove oEmbed links if the setting is enabled.
     */
    public function remove_oembed_links()
    {
        if (get_option('asseo_oembed')) {
            remove_action('wp_head', 'wp_oembed_add_discovery_links', 10);
            remove_action('wp_head', 'wp_oembed_add_host_js');
            remove_action('template_redirect', 'rest_output_link_header', 11, 0);
            ob_start(function ($output) {
                $output = preg_replace('/<link rel="alternate" type=".*?" \/>/', '', $output);
                return $output;
            });
        }
    }

    /**
     * Forcefully remove the generator meta tag.
     */
    public function remove_generator_tag()
    {
        if (get_option('asseo_generator_tag') == 1) {
            remove_action('wp_head', 'wp_generator');
            add_filter('the_generator', '__return_empty_string');
            ob_start(function ($output) {
                $output = preg_replace('/<meta name="generator" content=".*?" \/>/', '', $output);
                return $output;
            });
        }

    }

    /**
     * Remove the Pingback HTTP header if the setting is enabled.
     */
    public function remove_pingback_http_header()
    {
        if (get_option('asseo_pingback_http_header') == 1) {
            add_filter('wp_headers', function ($headers) {
                unset($headers['X-Pingback']);
                return $headers;
            });
        }
    }

    /**
     * Remove the 'Powered by' HTTP Header if the option is enabled.
     */
    public function remove_powered_by_http()
    {
        if (get_option('asseo_powered_by_http') == 1) {
            add_filter('wp_headers', function ($headers) {
                unset($headers['X-Powered-By']);
                return $headers;
            });
        }
    }

    /**
     * Remove global feed link if the option is enabled.
     */
    public function remove_global_feed()
    {
        if (get_option('asseo_global_feed') == 1) {
            remove_action('wp_head', 'feed_links', 2);
            remove_action('wp_head', 'feed_links_extra', 3);
        }
    }

    /**
     * Remove global comment feed link if the option is enabled.
     */
    public function remove_global_comment_feed()
    {
        if (get_option('asseo_global_comment_feed') == 1) {
            remove_action('wp_head', 'feed_links', 2);
        }
    }

    /**
     * Remove post comment feed link if the option is enabled.
     */
    public function remove_post_comment_feed()
    {
        if (get_option('asseo_post_comment_feed') == 1) {
            remove_action('wp_head', 'feed_links', 2);
        }
    }

    /**
     * Remove post author feed link if the option is enabled.
     */
    public function remove_post_authors_feed()
    {
        if (get_option('asseo_post_authors_feed') == 1) {
            remove_action('wp_head', 'feed_links', 2); // Removes all feed links, including author feeds
        }
    }

    /**
     * Remove category feed link if the option is enabled.
     */
    public function remove_category_feed()
    {
        if (get_option('asseo_category_feed') == 1) {
            // Remove the category feed link from the head section
            remove_action('wp_head', 'feed_links', 2); // Removes all feed links, including category feeds
        }
    }

    /**
     * Remove tag feed link if the option is enabled.
     */
    public function remove_tag_feed()
    {
        if (get_option('asseo_tag_feeds') == 1) {
            remove_action('wp_head', 'feed_links', 2);
        }
    }

    /**
     * Remove custom taxonomy feed link if the option is enabled.
     */
    public function remove_custom_taxonomy_feed()
    {
        if (get_option('asseo_taxonomy_feeds') == 1) {
            remove_action('wp_head', 'feed_links', 2);
        }
    }

    /**
     * Remove search results feed link if the option is enabled.
     */
    public function remove_search_results_feed()
    {
        if (get_option('asseo_Search_results_feeds') == 1) {
            remove_action('wp_head', 'feed_links', 2);
        }
    }

    /**
     * Remove Atom / RDF feed links if the option is enabled.
     */
    public function remove_atom_rdf_feeds()
    {
        if (get_option('asseo_atom_rdf_feeds') == 1) {
            remove_action('wp_head', 'rsd_link');
            remove_action('wp_head', 'feed_links_extra', 3);
        }
    }

    /**
     * Remove emoji scripts from the header.
     */
    public function remove_emoji_scripts()
    {
        if (get_option('asseo_emoji_scripts') == 1) {
            remove_action('wp_head', 'wp_generator');
            remove_action('wp_head', 'print_emoji_detection_script', 7);
            remove_action('wp_head', 'print_emoji_styles');
        }
    }

    /**
     * Remove emoji scripts that are printed in the footer.
     */
    public function remove_emoji_scripts_from_footer()
    {
        if (get_option('asseo_emoji_scripts') == 1) {
            remove_action('wp_print_scripts', 'print_emoji_detection_script');
        }
    }

    /**
     * Add custom rules to the robots.txt file.
     */
    public function add_robots_txt_rules($output, $public)
    {
        if (get_option('asseo_wpjson_api') == 1) {
            // Add disallow rule for WordPress JSON API
            $output .= "Disallow: /wp-json/\n";
        }

        return $output;
    }
}
