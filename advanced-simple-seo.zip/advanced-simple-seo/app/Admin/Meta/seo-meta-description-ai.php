<?php

namespace app\Admin\Meta;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
    exit;
}

class seoMetaAI
{

    public function __construct()
    {
        add_action('save_post', [$this, 'seo_meta_description_ai_save_meta_box_data']);
        add_action('wp_head', [$this, 'seo_meta_description_ai_output'], 1);
        add_action('admin_enqueue_scripts', [$this, 'seo_meta_description_ai_scripts']);
    }


    /**
     * Display the meta box content.
     */
    public function seo_meta_description_ai_meta_box_callback($post)
    {
        wp_nonce_field(
            'seo_meta_description_ai_save_meta_box_data',
            'seo_meta_description_ai_nonce'
        );

        $meta_description = get_post_meta(
            $post->ID,
            'asseoMetaDescription',
            true
        );
        ?>

        <?php
    }

    /**
     * Save the meta box data.
     */
    public function seo_meta_description_ai_save_meta_box_data($post_id)
    {
        if (!isset($_POST['seo_meta_description_ai_nonce'])) {
            return;
        }

        if (
            !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['seo_meta_description_ai_nonce'])),
                'seo_meta_description_ai_save_meta_box_data'
            )
        ) {
            return;
        }

        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        $meta_description = isset($_POST['asseoMetaDescription'])
            ? sanitize_text_field($_POST['asseoMetaDescription'])
            : '';

        update_post_meta($post_id, 'asseoMetaDescription', $meta_description);
    }

    /**
     * Output the SEO meta description in the head section.
     */
    public function seo_meta_description_ai_output()
    {
        if (is_singular()) {
            $meta_description = get_post_meta(get_the_ID(), 'asseoMetaDescription', true);
            if (!empty($meta_description)) {
                ?>
                <!-- This site is optimized with the <?php echo esc_html(ASSEO_TXTDOMAIN); ?> plugin v<?php echo esc_html(ASSEO_VERSION); ?> - <?php echo esc_url(ASSEO_PATH); ?> -->
                <meta name="description" content="<?php echo esc_attr($meta_description); ?>" />
                <!-- / <?php echo esc_html(ASSEO_TXTDOMAIN); ?> plugin. -->
                <?php
            }
        }
    }

    /**
     * Get stripped post content for AI processing.
     */
    public function seo_meta_description_ai_get_stripped_post_content($post)
    {
        $content = $post->post_content;
        $content = apply_filters('the_content', $content);
        $content = str_replace('<', ' <', $content);
        $content = wp_strip_all_tags($content, true);

        if (strlen($content) > 0) {
            $content = $post->post_title . '. ' . $content;
        } else {
            $content = $post->post_title;
        }

        return $content;
    }

    /**
     * Add JavaScript to the admin area.
     */
    public function seo_meta_description_ai_scripts($hook)
    {
        if (!in_array($hook, ['post.php', 'post-new.php'])) {
            return;
        }

        wp_enqueue_script(
            'seo-meta-description-ai-scripts',
            //plugin_dir_url(__FILE__) . 'js/seo-meta-description-ai.js',
            plugin_dir_url(__FILE__) . 'js/seo-meta-description-ai-open-ai.js',
            ['jquery'],
            ASSEO_VERSION,
            true
        );

        $content = $this->seo_meta_description_ai_get_stripped_post_content(get_post());
        wp_localize_script(
            'seo-meta-description-ai-scripts',
            'data',
            [
                'version' => ASSEO_VERSION,
                'host_name' => parse_url(get_bloginfo('url'), PHP_URL_HOST),
                'content' => $content,
            ]
        );
    }
}

new seoMetaAI();
