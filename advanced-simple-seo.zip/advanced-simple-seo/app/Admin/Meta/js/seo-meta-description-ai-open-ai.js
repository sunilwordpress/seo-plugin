"use strict";

document.addEventListener("DOMContentLoaded", function() {

	/** */
	function showMetaContent(response) {
	    
	    const json            = JSON.parse(response);
	    const metaDescription = json.choices[0]?.text.trim();

		const textarea = document.getElementById("asseoMetaDescription");
		
		if (metaDescription) {
			textarea.value = metaDescription;
			updateLabel(metaDescription.length);
		} else {
			textarea.value = "Failed to generate meta description.";
		}
	}

	/** */
	async function getMetaContent(content) {
		const API_URL = "https://api.openai.com/v1/completions";
		// const API_KEY = "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"; // Replace with your OpenAI API key
		const API_KEY = customVars.API_KEY;  // Use the localized API key

		const messages = [
			{
				role: "system", 
				content: "You are an assistant specialized in generating SEO meta descriptions."
			},
			{
				role: "user", 
				content: `Generate a concise and engaging meta description for the following content: \n\n${content}`
			}
		];

		const body = {
			model: "gpt-3.5-turbo",
			messages: messages,
			max_tokens: 100,
			temperature: 0.7
		};

		try {
			const response = await fetch(API_URL, {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
					"Authorization": `Bearer ${API_KEY}`
				},
				body: JSON.stringify(body)
			});

			if (!response.ok) {
				const errorData = await response.json();
				throw new Error(`API error: ${response.statusText}, Details: ${errorData.error?.message || "No additional details"}`);
			}

			const data = await response.json();
			showMetaContent(JSON.stringify(data));
		} catch (error) {
			const textarea = document.getElementById("asseoMetaDescription");
			textarea.value = `Error generating meta description: ${error.message}`;
		}
	}

	/** */
	function updateLabel(length) {
		// const label = document.getElementById("asseoMetaDescription");
		// const span  = label.getElementsByTagName("span")[0];
		
		// if (length !== undefined) {
		// 	span.textContent = length;
		// }

		// if (length >= 110 && length <= 160) {
		//     label.style.color = "green";
		// } else {
		//     label.style.color = "red";
	  	// }  
	}
	
	/** */
	function setTextAreaListener() {
		const textarea = document.getElementById("asseoMetaDescription");
		textarea.addEventListener("input", function() {
		    updateLabel(textarea.value.length);
	  	});
	}
	
	/** */
	function setButtonListener() {
		const button   = document.getElementById("seo-meta-description-ai-button");
		const textarea = document.getElementById("asseoMetaDescription");
		
		button.addEventListener("click", function() {
			if (typeof data === "undefined" || !data.content) {
				textarea.value = "No content detected. Please save draft or publish post first.";
				return;
			}
			
			textarea.value = "Generating description ...";
			updateLabel(0);
			getMetaContent(data.content);
		});
	}
	
	updateLabel();
	setTextAreaListener();
	setButtonListener();
});
