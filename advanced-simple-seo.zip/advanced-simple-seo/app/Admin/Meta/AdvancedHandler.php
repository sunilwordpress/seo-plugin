<?php

namespace App\Admin\Meta;

class AdvancedHandler
{
    public function __construct()
    {
        // Hook the breadcrumb generation to wp_head
        add_action('wp_head', [$this, 'asseo_generate_breadcrumbs']);
        
        // Register the shortcode for breadcrumbs
        add_shortcode('asseo_breadcrumbs', [$this, 'asseo_breadcrumbs_shortcode']);

        // Hook the function into wp_head to add structured data
        add_action('wp_head', [$this, 'asseo_add_organization_personal_schema']);
    }

    // Original breadcrumb generation method (for wp_head)
    public function asseo_generate_breadcrumbs()
    {
        // if (get_option('asseo_breadcrumbs_active')) {
        //     $separator = get_option('asseo_between_breadcrumbs', '>');
        //     $home_anchor_text = get_option('asseo_anchor_text', 'Home');
        //     $prefix = get_option('asseo_prefix_breadcrumb_path', '');

        //     $breadcrumbs = '<nav class="breadcrumbs">';
        //     if (!empty($prefix)) {
        //         $breadcrumbs .= '<span class="prefix">' . esc_html($prefix) . ': </span> ';
        //     }
        //     $breadcrumbs .= '<a href="' . esc_url(home_url('/')) . '">' . esc_html($home_anchor_text) . '</a>';
        //     if (is_category() || is_single()) {
        //         $breadcrumbs .= ' ' . esc_html($separator) . ' ';

        //         if (is_category()) {
        //             $category = get_queried_object();
        //             $breadcrumbs .= '<span>' . esc_html($category->name) . '</span>';
        //         } elseif (is_single()) {
        //             $category = get_the_category();
        //             if ($category) {
        //                 $breadcrumbs .= '<a href="' . esc_url(get_category_link($category[0]->term_id)) . '">' . esc_html($category[0]->cat_name) . '</a>';
        //                 $breadcrumbs .= ' ' . esc_html($separator) . ' ';
        //             }
        //             $breadcrumbs .= '<span>' . esc_html(get_the_title()) . '</span>';
        //         }
        //     }

        //     $breadcrumbs .= '</nav>';
        //     echo $breadcrumbs;
        // }
    }

    // Breadcrumb shortcode handler
    public function asseo_breadcrumbs_shortcode()
    {
        if (get_option('asseo_breadcrumbs_active')) {
            $separator = get_option('asseo_between_breadcrumbs', '>');
            $home_anchor_text = get_option('asseo_anchor_text', 'Home');
            $prefix = get_option('asseo_prefix_breadcrumb_path', '');

            $breadcrumbs = '<nav class="breadcrumbs">';
            if (!empty($prefix)) {
                $breadcrumbs .= '<span class="prefix">' . esc_html($prefix) . ': </span> ';
            }
            $breadcrumbs .= '<a href="' . esc_url(home_url('/')) . '">' . esc_html($home_anchor_text) . '</a>';
            if (is_category() || is_single()) {
                $breadcrumbs .= ' ' . esc_html($separator) . ' ';

                if (is_category()) {
                    $category = get_queried_object();
                    $breadcrumbs .= '<span>' . esc_html($category->name) . '</span>';
                } elseif (is_single()) {
                    $category = get_the_category();
                    if ($category) {
                        $breadcrumbs .= '<a href="' . esc_url(get_category_link($category[0]->term_id)) . '">' . esc_html($category[0]->cat_name) . '</a>';
                        $breadcrumbs .= ' ' . esc_html($separator) . ' ';
                    }
                    $breadcrumbs .= '<span>' . esc_html(get_the_title()) . '</span>';
                }
            }

            $breadcrumbs .= '</nav>';

            return $breadcrumbs; // Return breadcrumbs instead of echoing
        }
    }

    // asseo_add_organization_personal_schema
    public function asseo_add_organization_personal_schema()
    {
        if (get_option('asseo_organization')) {
            // Get the saved options
            $organization_name = get_option('asseo_organization_name');
            $organization_logo = get_option('asseo_organization_logo');

            // Check if both fields are filled
            if (!empty($organization_name) && !empty($organization_logo)) {
                // Build the JSON-LD structured data
                $schema = [
                    "@context" => "https://schema.org",
                    "@type" => "Organization",
                    "name" => esc_html($organization_name),
                    "logo" => esc_url($organization_logo),
                    "url" => esc_url(home_url('/')),
                ];

                // Output the structured data in the <head>
                echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>';
            }
        }

        if (get_option('asseo_person')) {
            // Get the saved options for the user and logo
            $person_id = get_option('asseo_users'); // Get the selected user ID
            $person_logo = get_option('asseo_person_logo'); // Get the personal logo URL

            // Check if the user and logo are provided
            if (!empty($person_id) && !empty($person_logo)) {
                // Get user information
                $user = get_user_by('ID', $person_id);
                if ($user) {
                    // Build the JSON-LD structured data for a Person
                    $schema = [
                        "@context" => "https://schema.org",
                        "@type" => "Person",
                        "name" => esc_html($user->display_name),
                        "image" => esc_url($person_logo),
                        "url" => esc_url(get_author_posts_url($user->ID)), // Link to the user's posts (optional)
                        "sameAs" => [] // Add social profiles or other related links if needed
                    ];

                    // Output the structured data in the <head>
                    echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>';
                }
            }
        }
    }
}

