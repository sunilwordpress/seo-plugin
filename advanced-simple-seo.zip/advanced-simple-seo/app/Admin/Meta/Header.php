<?php 

namespace app\Admin\Meta;
wp_body_open();

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}

use app\Helpers as Helper;

/**
 * Header class. This is the meat and potatoes.
 * All meta data is gathered and printed within
 * the header.
 */
class Header {

    public function __construct() {
		global $post;
		global $wp_query;

		$keywords = null;
		$description = null;

		/**
		 *
		 * Remember always escape late, escape when you use a variable.
		 *
		 * esc_attr() within a attribute; src="esc_attr($value)"
		 * esc_html() within for a variable; <p>esc_html($value)</p>
		 * esc_url() within a href attribute; href="esc_url($value)"
		 * esc_textarea() within a textarea; <textarea>esc_textarea($value)</textarea>
		 *
		 */

		if (is_front_page() && is_home()) { /* Default Homepage */
			$description = get_option('asseo_default_meta_description');
			$keywords = get_option('asseo_default_meta_keywords');
		} elseif (is_home()) { /* Blog Page */
			$description = get_post_meta(get_option('page_for_posts'), 'asseo_meta_description', true);
			$keywords = get_post_meta(get_option('page_for_posts'), 'asseo_meta_keywords', true);
		} elseif ((is_front_page() || is_home()) && isset($post->ID)) { /* Static */
			$keywords = get_post_meta($post->ID, 'asseo_meta_keywords', true);
			$description = get_post_meta($post->ID, 'asseo_meta_description', true);
		} elseif (isset($post->ID)) {
			$keywords = get_post_meta($post->ID, 'asseo_meta_keywords', true);
			$description = get_post_meta($post->ID, 'asseo_meta_description', true);
		}

		if ($keywords) {
			echo '<meta name="keywords" content="'.esc_attr($keywords).'" />' . "\n";
		}

		$asseo_canonical_url = null;
		if (empty($asseo_canonical_url) && isset($post->ID)) {
			$asseo_canonical_url = get_post_meta($post->ID, 'asseo_canonical_url', true);
		}

		if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
			if (is_shop()) {
				$shop_page_id = get_option('woocommerce_shop_page_id');
				$description = get_post_meta($shop_page_id, 'asseo_meta_description', true);
				$description = apply_filters('asseo_meta_description', $description);

				$asseo_canonical_url = get_post_meta($shop_page_id, 'asseo_canonical_url', true);
				$asseo_canonical_url = apply_filters('asseo_canonical_url', $asseo_canonical_url);
			} elseif (is_product_category() || is_product_tag()) {
				$term = $wp_query->get_queried_object();
				if (!empty($term->term_id)) {
					$term_meta = get_option("taxonomy_".$term->term_id);

					if (!empty($term_meta['asseo_description']))
					$description = $term_meta['asseo_description'];

					if (!empty($term_meta['asseo_canonical_url']))
					$asseo_canonical_url = $term_meta['asseo_canonical_url'];
				}
			}
		}

		if (is_category() || is_tag()) {
			$term = $wp_query->get_queried_object();
			if (!empty($term->term_id)) {
				$term_meta = get_option("taxonomy_".$term->term_id);

				if (!empty($term_meta['asseo_description']))
				$description = $term_meta['asseo_description'];

				if (!empty($term_meta['asseo_canonical_url']))
				$asseo_canonical_url = $term_meta['asseo_canonical_url'];
			}
		}

		if ($description) {
			echo '<meta name="description" content="'.esc_attr($description).'" />' . "\n";
		}		
		

		if (isset($post->ID)) {
			$asseo_robot_noindex = get_post_meta($post->ID, 'asseo_robot_noindex', true);
			$asseo_robot_nofollow = get_post_meta($post->ID, 'asseo_robot_nofollow', true);
		
			if (!empty($asseo_robot_noindex) && !empty($asseo_robot_nofollow)) {
				echo '<meta name="robots" content="noindex, nofollow" />' . "\n";
			} elseif (empty($asseo_robot_noindex) && !empty($asseo_robot_nofollow)) {
				echo '<meta name="robots" content="nofollow" />' . "\n";
			}
			if (!empty($asseo_robot_noindex) && empty($asseo_robot_nofollow)) {
				echo '<meta name="robots" content="noindex" />' . "\n";
			}

			$asseo_fb_title = get_post_meta($post->ID, 'asseo_fb_title', true);
			$asseo_fb_description = get_post_meta($post->ID, 'asseo_fb_description', true);
			$asseo_fb_image_id = get_post_meta($post->ID, 'asseo_fb_image', true);
		}

		$current_url = null;
		$asseo_fb_image = null;
		$asseo_fb_app_id = get_option('asseo_fb_app_id');
		if (isset($asseo_fb_image_id)) {
			$asseo_fb_image = wp_get_attachment_image_url($asseo_fb_image_id, 'full');
		}

		if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
			if (is_shop()) {
				$shop_page_id = get_option('woocommerce_shop_page_id');
				$asseo_fb_title = get_post_meta($shop_page_id, 'asseo_fb_title', true);
				$asseo_fb_description = get_post_meta($shop_page_id, 'asseo_fb_description', true);
				$asseo_fb_image_id = get_post_meta($shop_page_id, 'asseo_fb_image', true);
				$asseo_fb_image = wp_get_attachment_image_url($asseo_fb_image_id, 'full');
				$current_url = get_permalink($shop_page_id);
			}
		}

		if (empty($current_url) && (is_category() || is_tag() || is_tax())) {
			$obj_id = get_queried_object_id();
			$current_url = get_term_link($obj_id);
		} elseif (empty($current_url) && isset($post->ID)) {
			$current_url = get_permalink($post->ID);
		}

		if (empty($asseo_fb_title)) {
			$asseo_fb_title = Title::getTitle();
		}

		if ($asseo_fb_app_id) { echo '<meta property="fb:app_id" content="'.esc_attr($asseo_fb_app_id).'" />' . "\n"; }
		echo '<meta property="og:site_name" content="'.esc_attr(get_bloginfo('name')).'" />'."\n";
		if ($current_url) { echo '<meta property="og:url" content="'.esc_url($current_url).'" />' . "\n"; }
		if ($current_url) { echo '<meta property="og:type" content="website" />'."\n"; }
		if ($asseo_fb_title) { echo '<meta property="og:title" content="'.esc_attr($asseo_fb_title).'" />' . "\n"; }
		if (isset($asseo_fb_description)) { echo '<meta property="og:description" content="'.esc_attr($asseo_fb_description).'" />' . "\n"; }
		
		/* Default to the featured image sense we have no Facebook image. */
		if (empty($asseo_fb_image)) {
			$asseo_fb_image = wp_get_attachment_url(get_post_thumbnail_id());
		}
		
		if (!empty($asseo_fb_image)) {
			echo '<meta property="og:image" content="'.esc_url($asseo_fb_image).'" />' . "\n";
			echo '<meta property="og:image:url" content="'.esc_url($asseo_fb_image).'" />' . "\n";
		}
		
		if (isset($post->ID)) {
			$asseo_tw_title = get_post_meta($post->ID, 'asseo_tw_title', true);
			$asseo_tw_description = get_post_meta($post->ID, 'asseo_tw_description', true);
			$asseo_tw_image_id = get_post_meta($post->ID, 'asseo_tw_image', true);
		}
		
		$asseo_tw_image = null;
		$asseo_twitter_username = get_option('asseo_twitter_username');
		if (!empty($asseo_tw_image_id)) {
			$asseo_tw_image = wp_get_attachment_image_url($asseo_tw_image_id, 'full');
		}

		if (empty($asseo_tw_title)) {
			$asseo_tw_title = Title::getTitle();
		}
		if (empty($asseo_tw_description)) {
			$asseo_tw_description = $description;
		}

		if ($asseo_twitter_username) { echo '<meta name="twitter:site" content="'.esc_attr($asseo_twitter_username).'">' . "\n"; }

		if ($asseo_tw_title) { echo '<meta name="twitter:title" content="'.esc_attr($asseo_tw_title).'" />' . "\n"; }
		if ($asseo_tw_description) { echo '<meta name="twitter:description" content="'.esc_attr($asseo_tw_description).'" />' . "\n"; }
		
		/* Twitter image or featured image */
		if (empty($asseo_tw_image) && isset($post->ID) && has_post_thumbnail($post->ID)) {
			$asseo_tw_image = wp_get_attachment_url(get_post_thumbnail_id());
		}
		
		if (!empty($asseo_tw_image)) {
			echo '<meta name="twitter:image" content="'.esc_url($asseo_tw_image).'" />' . "\n";
			echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		}

		$asseo_gsite_verification = esc_attr(get_option('asseo_gsite_verification'));
		if ($asseo_gsite_verification) {
			echo '<meta name="google-site-verification" content="'.esc_attr($asseo_gsite_verification).'" />' . "\n";
		}

		$asseo_bing = esc_attr(get_option('asseo_bing'));
		if ($asseo_bing) {
			echo '<meta name="msvalidate.01" content="'.esc_attr($asseo_bing).'" />' . "\n";
		}

		$asseo_yandex = esc_attr(get_option('asseo_yandex'));
		if ($asseo_yandex) {
			echo '<meta name="yandex-verification" content="'.esc_attr($asseo_yandex).'" />' . "\n";
		}
		
		$asseo_baidu = esc_attr(get_option('asseo_baidu'));
		if ($asseo_baidu) {
			echo '<meta name="baidu-site-verification" content="'.esc_attr($asseo_baidu).'" />' . "\n";
		}

		$asseo_pinterest = esc_attr(get_option('asseo_pinterest'));
		if ($asseo_pinterest) {
			echo '<meta name="pinterest-verification" content="'.esc_attr($asseo_pinterest).'" />' . "\n";
		}

		if (!empty($asseo_canonical_url)) {
			echo '<link rel="canonical" href="'.esc_url($asseo_canonical_url).'" />' . "\n";
		}

	}

	
}


?>