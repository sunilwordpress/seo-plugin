<?php 

namespace app\Admin\Meta;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}
class Taxonomy {
    public function editMetaBox($term) {
		$term_meta = get_option("taxonomy_".$term->term_id);
				
		$meta_title = null;
		if (isset($term_meta['asseo_title'])) {
			$meta_title = $term_meta['asseo_title'];
		}
		
		$meta_description = null;
		if (isset($term_meta['asseo_description'])) {
			$meta_description = $term_meta['asseo_description'];
		}
		
		$asseo_robot_noindex = null;
		if (isset($term_meta['asseo_robot_noindex'])) {
			$asseo_robot_noindex = $term_meta['asseo_robot_noindex'];
		}
		
		$asseo_robot_nofollow = null;
		if (isset($term_meta['asseo_robot_nofollow'])) {
			$asseo_robot_nofollow = $term_meta['asseo_robot_nofollow'];
		}
		
		$canonical_url = null;
		if (!empty($term_meta['asseo_canonical_url'])) {
			$canonical_url = $term_meta['asseo_canonical_url'];
		}

		echo '
		<tr class="form-field">
			<th scope="row" valign="top"><label for="asseo_title">'.__('SEO Title', ASSEO_TXTDOMAIN).'</label></th>
			<td><input type="text" name="term_meta[asseo_title]" id="asseo_title" value="'.esc_attr($meta_title).'"></td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="asseo_description">'.__('SEO Description', ASSEO_TXTDOMAIN).'</label></th>
			<td><input type="text" name="term_meta[asseo_description]" id="asseo_description" value="'.esc_attr($meta_description).'"></td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="asseo_robot_noindex">'.__('Robots Meta NOINDEX', ASSEO_TXTDOMAIN).'</label></th>
			<td><input type="hidden" name="term_meta[asseo_robot_noindex]" value="0" /><input type="checkbox" name="term_meta[asseo_robot_noindex]" id="asseo_robot_noindex" value="1" '.(!empty($asseo_robot_noindex) ? 'checked="checked"' : '').'></td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="asseo_robot_nofollow">'.__('Robots Meta NOFOLLOW', ASSEO_TXTDOMAIN).'</label></th>
			<td><input type="hidden" name="term_meta[asseo_robot_nofollow]" value="0" /><input type="checkbox" name="term_meta[asseo_robot_nofollow]" id="asseo_robot_nofollow" value="1" '.(!empty($asseo_robot_nofollow) ? 'checked="checked"' : '').'></td>
		</tr>
		<tr class="form-field">
			<th scope="row" valign="top"><label for="asseo_canonical_url">'.__('Canonical URL', ASSEO_TXTDOMAIN).'</label></th>
			<td><input type="text" name="term_meta[asseo_canonical_url]" id="asseo_canonical_url" value="'.esc_attr($canonical_url).'"></td>
		</tr>
		';
	}
	
	public function newMetaBox() {
		echo '<div class="form-field">
			<label for="term_meta[asseo_title]">'.__('SEO Title', ASSEO_TXTDOMAIN).'</label>
			<input type="text" name="term_meta[asseo_title]" id="term_meta[asseo_title]" value="">
		</div>
		<div class="form-field">
			<label for="term_meta[asseo_description]">'.__('SEO Description', ASSEO_TXTDOMAIN).'</label>
			<input type="text" name="term_meta[asseo_description]" id="term_meta[asseo_description]" value="">
		</div>
		<div class="form-field">
			<label for="term_meta[asseo_robot_noindex]" style="display: inline-block;">'.__('Robots Meta NOINDEX', ASSEO_TXTDOMAIN).'</label>
			<input type="checkbox" name="term_meta[asseo_robot_noindex]" id="term_meta[asseo_robot_noindex]" value="1">
		</div>
		<div class="form-field">
			<label for="term_meta[asseo_robot_nofollow]" style="display: inline-block;">'.__('Robots Meta NOFOLLOW', ASSEO_TXTDOMAIN).'</label>
			<input type="checkbox" name="term_meta[asseo_robot_nofollow]" id="term_meta[asseo_robot_nofollow]" value="1">
		</div>
		<div class="form-field">
			<label for="term_meta[asseo_canonical_url]">'.__('Canonical URL', ASSEO_TXTDOMAIN).'</label>
			<input type="text" name="term_meta[asseo_canonical_url]" id="term_meta[asseo_canonical_url]" value="">
		</div>';
	}
	
}

?>