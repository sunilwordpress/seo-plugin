<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Function to export settings
function asseo_export_settings() {
    // Get all registered options
    $settings = array(
        'asseo_website_name' => get_option('asseo_website_name'),
        'asseo_tagline' => get_option('asseo_tagline'),
        // Add more options as required...
    );

    // Convert settings to JSON
    $json_data = json_encode($settings, JSON_PRETTY_PRINT);

    // Send JSON file as a download
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="asseo-settings.json"');
    echo $json_data;
    exit;
}

// Function to import settings
function asseo_import_settings($file_path) {
    $file_content = file_get_contents($file_path);
    $settings = json_decode($file_content, true);

    if (is_array($settings)) {
        foreach ($settings as $key => $value) {
            update_option($key, $value);
        }
    }
}

// Handle the export and import actions
add_action('admin_init', function () {
    if (isset($_POST['asseo_export_settings'])) {
        asseo_export_settings();
    }

    if (isset($_POST['asseo_import_settings']) && !empty($_FILES['asseo_import_file']['tmp_name'])) {
        asseo_import_settings($_FILES['asseo_import_file']['tmp_name']);
        wp_redirect(admin_url('admin.php?page=simpleSEOAdminOptions'));
        echo '<script>
            
        </script>';
        exit;
    }
});
