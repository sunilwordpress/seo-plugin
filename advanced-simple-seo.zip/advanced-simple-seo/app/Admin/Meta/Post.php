<?php

namespace app\Admin\Meta;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}

use app\Helpers as Helper;
class Post
{

	public function __construct($post)
	{
		$form = new Helper\Form();

		wp_nonce_field(ASSEO_PATH, 'asseo_nonce');

		// Render the SEO Score Section
		$content = '<div class="as-seo-section">';
		$content .= '<h3>' . __('SEO Score', ASSEO_TXTDOMAIN) . '</h3>';
		$content .= '<p>' . __('Your SEO score is:', ASSEO_TXTDOMAIN) . ' 
              <span id="seo-score-static">0</span>/100</p>';  // Static score remains as it is
		$content .= '<div class="seo-score-progress-wrapper">';
		$content .= '<progress id="seo-score-progress" value="0" max="100"></progress>';
		$content .= '</div>'; // .seo-score-progress-wrapper
		$content .= '<p id="seo-feedback" style="font-style: italic; color: #555;"></p>';
		$content .= '</div>'; // .as-seo-section
		$content .= '<div class="as-seo-metabox-tabs">';
		$content .= '<input id="as-seo-tab1" type="radio" name="tab-group" checked="checked" />';
		$content .= '<label class="tab" for="as-seo-tab1" class="active">' . __('SEO', ASSEO_TXTDOMAIN) . '</label>';
		$content .= '<input id="as-seo-tab2" type="radio" name="tab-group" />';
		$content .= '<label class="tab" for="as-seo-tab2">' . __('Keywords', ASSEO_TXTDOMAIN) . '</label>';
		$content .= '<input id="as-seo-tab3" type="radio" name="tab-group" />';
		$content .= '<label class="tab" for="as-seo-tab3">' . __('Robots', ASSEO_TXTDOMAIN) . '</label>';
		$content .= '<input id="as-seo-tab4" type="radio" name="tab-group" />';
		$content .= '<label class="tab" for="as-seo-tab4">' . __('Facebook', ASSEO_TXTDOMAIN) . '</label>';
		$content .= '<input id="as-seo-tab5" type="radio" name="tab-group" />';
		$content .= '<label class="tab" for="as-seo-tab5">' . __('Twitter', ASSEO_TXTDOMAIN) . '</label>';
		$content .= '<input id="as-seo-tab6" type="radio" name="tab-group" />';
		$content .= '<label class="tab" for="as-seo-tab6">' . __('Advanced', ASSEO_TXTDOMAIN) . '</label>';

		$content .= '<div id="as-seo-preview" class="as-seo-tab">';

		$asseo_meta_title = esc_html(get_post_meta($post->ID, 'asseo_meta_title', true));
		$asseo_meta_description = esc_html(get_post_meta($post->ID, 'asseo_meta_description', true));
		$asseo_canonical_url = esc_html(get_post_meta($post->ID, 'asseo_canonical_url', true));
		$asseo_meta_keywords = esc_html(get_post_meta($post->ID, 'asseo_meta_keywords', true));
		$asseo_robot_noindex = esc_html(get_post_meta($post->ID, 'asseo_robot_noindex', true));
		$asseo_robot_nofollow = esc_html(get_post_meta($post->ID, 'asseo_robot_nofollow', true));
		$asseo_fb_title = esc_html(get_post_meta($post->ID, 'asseo_fb_title', true));
		$asseo_fb_description = esc_html(get_post_meta($post->ID, 'asseo_fb_description', true));
		$asseo_fb_image = esc_html(get_post_meta($post->ID, 'asseo_fb_image', true));
		$asseo_tw_title = esc_html(get_post_meta($post->ID, 'asseo_tw_title', true));
		$asseo_tw_description = esc_html(get_post_meta($post->ID, 'asseo_tw_description', true));
		$asseo_tw_image = esc_html(get_post_meta($post->ID, 'asseo_tw_image', true));
		$current_url = get_permalink($post->ID);

		$content .= '<div class="as-seo-section">';
		$content .= '<h3>' . __('Preview', ASSEO_TXTDOMAIN) . '</h3>';
		$content .= '<div class="preview_snippet">';
		$content .= '<div id="asseo_snippet">';
		$content .= '<a><span id="asseo_snippet_title">' . $asseo_meta_title . '</span></a>';
		$content .= '<div class="as-seo-current-url">';
		$content .= '<cite id="asseo_snippet_link">' . $current_url . '</cite>';
		$content .= '</div>'; /* as-seo-current-url */
		$content .= '<span id="asseo_snippet_description">' . esc_attr($asseo_meta_description) . '</span>';
		$content .= '</div>'; /* asseo_snippet */
		$content .= '</div>'; /* preview_snippet */
		$content .= '</div>'; /* as-seo-section */

		$content .= '<div class="as-seo-section">';
		$content .= '<h3>';
		$content .= __('SEO', ASSEO_TXTDOMAIN);
		$content .= '</h3>';

		$content .= $form->input('asseo_meta_title', array(
			'label' => __('Title', ASSEO_TXTDOMAIN),
			'value' => $asseo_meta_title,
		));
		$content .= '<p><span id="asseo_title_count">0</span> ' . __('characters. Most search engines use a maximum of 60 chars for the title.', ASSEO_TXTDOMAIN) . '</p>';


		$meta_description = get_post_meta($post->ID, 'asseoMetaDescription', true);
		$content .= '<div class="meta-description-container">';
		$content .= '<label for="asseoMetaDescription" id="asseoMetaDescriptionLabel" class="post-attributes-label">Description</label>';
		// $content .= '<label id="seo-meta-description-ai-label" for="asseoMetaDescription">';
		// $content .= __('', 'text-domain') . '<span id="meta-desc-length"></span>';
		// $content .= '</label>';
		$content .= '<textarea id="asseoMetaDescription" name="asseoMetaDescription" style="width: 100%;" rows="4">' . esc_textarea($meta_description) . '</textarea>';
		$content .= '<p><span id="asseo_desc_count">' . strlen(esc_html($meta_description)) . '</span> ';
		$content .= __('characters. Most search engines use a maximum of 160 chars for the description.', 'text-domain') . '</p>';
		if (get_option('asseo_ai_meta_active') == 1) {
			$content .= '<button id="seo-meta-description-ai-button" type="button" class="button">';
			$content .= __('AI Meta Description Generator', 'text-domain');
			$content .= '</button>';
		}

		$content .= '</div>'; // Close meta-description-container


		$content .= '</div>'; /* .as-seo-section */
		$content .= '</div>'; /* #as-seo-preview */

		$content .= '<div id="as-seo-keywords" class="as-seo-tab">';
		$content .= '<div class="as-seo-section">';

		$content .= '<h3>';
		$content .= __('Keywords', ASSEO_TXTDOMAIN);
		$content .= '</h3>';
		$content .= $form->textarea('asseo_meta_keywords', array(
			'label' => __('Meta keywords', ASSEO_TXTDOMAIN),
			'value' => $asseo_meta_keywords,
		));

		$content .= '<p>';
		$content .= __('A comma separated list of your most important keywords for this page that will be written as META keywords.', ASSEO_TXTDOMAIN);
		$content .= '</p>';

		$content .= '</div>'; /* .as-seo-section */
		$content .= '</div>'; /* as-seo-keywords */

		$content .= '<div id="as-seo-robots" class="as-seo-tab">';
		$content .= '<div class="as-seo-section">';
		$content .= '<h3>' . __('Robots', ASSEO_TXTDOMAIN) . '</h3>';

		$content .= $form->input('asseo_robot_noindex', array(
			'type' => 'checkbox',
			'label' => __('Robots Meta NOINDEX', ASSEO_TXTDOMAIN),
			'checked' => $asseo_robot_noindex,
		));

		$content .= $form->input('asseo_robot_nofollow', array(
			'type' => 'checkbox',
			'label' => __('Robots Meta NOFOLLOW', ASSEO_TXTDOMAIN),
			'checked' => $asseo_robot_nofollow,
		));

		$content .= '</div>'; /* .as-seo-section */
		$content .= '</div>'; /* #as-seo-robots */



		$content .= '<div id="as-seo-facebook" class="as-seo-tab">';
		$content .= '<div class="as-seo-section">';
		$content .= '<h3>' . __('Facebook', ASSEO_TXTDOMAIN) . '</h3>';

		$content .= $form->input('asseo_fb_title', array(
			'label' => __('Facebook Title', ASSEO_TXTDOMAIN),
			'value' => $asseo_fb_title,
		));

		$content .= '<p>';
		$content .= __('This is the title shared on Facebook, if left blank the default title for the post will be used.', ASSEO_TXTDOMAIN);
		$content .= '</p>';

		$content .= $form->textarea('asseo_fb_description', array(
			'label' => __('Facebook Description', ASSEO_TXTDOMAIN),
			'value' => $asseo_fb_description,
		));

		$content .= '<p>' . __('This is the description shared on Facebook, if left blank the default description for the post will be used.', ASSEO_TXTDOMAIN) . '</p>';

		$content .= '<div class="fb-img-container">';

		$image = null;
		if (intval($asseo_fb_image) > 0) {
			$image = wp_get_attachment_image($asseo_fb_image, 'medium', false, array('id' => 'asseo-fb-preview-image', 'class' => 'media-input', 'style' => 'display:block !important;'));
		} else {
			//$image = '<img id="asseo-fb-preview-image" src="" class="media-input" />';
		}

		$content .= $image . '</div><div class="clearfix">&nbsp;</div>';

		$content .= '<input type="hidden" name="asseo_fb_image" value="' . esc_attr($asseo_fb_image) . '" id="asseo-fb-image" />
		<input type="button" class="button-primary asseo-media-button" value="' . __('Select an Image', ASSEO_TXTDOMAIN) . '" id="asseo_fb_media_manager"/>
		<input type="button" class="button-primary asseo-media-button" value="' . __('Remove Image', ASSEO_TXTDOMAIN) . '" id="asseo-fb-media-remove"/>';

		$content .= '<p>' . __('If you want to override the image used on Facebook for this post, upload / choose an image here. The size of the image file must not exceed 8 MB. ', ASSEO_TXTDOMAIN) . '</p>';

		$content .= '</div>'; /* .as-seo-section */
		$content .= '</div>'; /* #as-seo-facebook */



		$content .= '<div id="as-seo-twitter" class="as-seo-tab">';
		$content .= '<div class="as-seo-section">';
		$content .= '<h3>' . __('Twitter', ASSEO_TXTDOMAIN) . '</h3>';

		$content .= $form->input('asseo_tw_title', array(
			'label' => __('Twitter Title', ASSEO_TXTDOMAIN),
			'value' => $asseo_tw_title,
		));

		$content .= '<p>' . __('This is the title shared on Twitter, if left blank the default title for the post will be used.', ASSEO_TXTDOMAIN) . '</p>';

		$content .= $form->textarea('asseo_tw_description', array(
			'label' => __('Twitter Description', ASSEO_TXTDOMAIN),
			'value' => $asseo_tw_description,
		));

		$content .= '<p>' . __('This is the description shared on Twitter, if left blank the default description for the post will be used.', ASSEO_TXTDOMAIN) . '</p>';

		$content .= '<div class="tw-img-container">';

		$image = null;
		if (intval($asseo_tw_image) > 0) {
			$image = wp_get_attachment_image($asseo_tw_image, 'medium', false, array('id' => 'asseo-tw-preview-image', 'class' => 'media-input', 'style' => 'display:block !important;'));
		} else {
			//$image = '<img id="asseo-tw-preview-image" src="" class="media-input" />';
		}

		$content .= $image . '</div><div class="clearfix">&nbsp;</div>';

		$content .= '<input type="hidden" name="asseo_tw_image" value="' . esc_attr($asseo_tw_image) . '" id="asseo-tw-image" />
		<input type="button" class="button-primary asseo-media-button" value="' . __('Select an Image', ASSEO_TXTDOMAIN) . '" id="asseo_tw_media_manager"/>
		<input type="button" class="button-primary asseo-media-button" value="' . __('Remove Image', ASSEO_TXTDOMAIN) . '" id="asseo-tw-media-remove"/>';

		$content .= '<p>' . __('If you want to override the image used on Twitter for this post, upload / choose an image here.', ASSEO_TXTDOMAIN) . '</p>';

		$content .= '</div>'; /* .as-seo-section */
		$content .= '</div>'; /* #as-seo-twitter */

		$content .= '<div id="as-seo-advanced" class="as-seo-tab">';
		$content .= '<div class="as-seo-section">';
		$content .= '<h3>' . __('Advanced', ASSEO_TXTDOMAIN) . '</h3>';

		$content .= $form->input('asseo_canonical_url', array(
			'label' => 'Canonical URL',
			'value' => $asseo_canonical_url,
		));
		$content .= '<div class="clearfix">&nbsp;</div>';

		$content .= '</div>'; /* .as-seo-section */
		$content .= '</div>'; /* #as-seo-advanced */

		$content .= '<div class="clearfix">&nbsp;</div>';
		$content .= '</div>'; /* .as-seo-metabox-tabs */
		$content .= '</div>'; // .as-seo-section		

		// Closing metabox container
		$content .= '</div>'; /* .as-seo-metabox-tabs */
		echo $content;

		// Enqueue the real-time SEO score calculation script
		add_action('admin_footer', array($this, 'enqueue_realtime_seo_score_script'));
	}

	// Function to enqueue the JavaScript for real-time score calculation
	public function enqueue_realtime_seo_score_script()
	{
		?>
		<script type="text/javascript">
			(function ($) {
				$(document).ready(function () {
					// Function to calculate the SEO score
					function calculateSEOScore() {
						let score = 0;

						// Get values from the fields
						const title = $('#asseoMetaTitle').val() || '';
						const description = $('#asseoMetaDescription').val() || '';
						const keywords = $('#asseoMetaKeywords').val() || '';
						const fbTitle = $('#asseoFbTitle').val() || '';
						const twTitle = $('#asseoTwTitle').val() || '';
						const noindex = $('#asseoRobotNoindex').is(':checked'); // Boolean
						const nofollow = $('#asseoRobotNofollow').is(':checked'); // Boolean

						// Title scoring
						const titleLength = title.length;
						if (titleLength > 0) score += 20; // Title exists
						if (titleLength >= 10 && titleLength <= 60) score += 10; // Ideal title length

						// Description scoring
						const descriptionLength = description.length;
						if (descriptionLength > 0) score += 20; // Description exists
						if (descriptionLength >= 50 && descriptionLength <= 160) score += 10; // Ideal description length

						// Keywords scoring
						if (keywords.trim().length > 0) score += 10; // Keywords exist

						// Robots meta scoring
						if (!noindex) score += 5; // Noindex not checked
						if (!nofollow) score += 5; // Nofollow not checked

						// Facebook title scoring
						if (fbTitle.trim().length > 0) score += 10; // Facebook title exists

						// Twitter title scoring
						if (twTitle.trim().length > 0) score += 10; // Twitter title exists

						// Update character counts
						$('#asseo_title_count').text(titleLength);
						$('#asseo_desc_count').text(descriptionLength);

						// Update the static SEO score
						$('#seo-score-static').text(score);

						// Provide feedback
						const feedback = $('#seo-feedback');
						if (score >= 70) {
							feedback.text('Great! Your SEO score is looking strong.');
							feedback.css('color', 'green');
						} else if (score >= 40) {
							feedback.text('Good, but you can make further improvements.');
							feedback.css('color', 'orange');
						} else {
							feedback.text('Needs improvement. Please optimize further.');
							feedback.css('color', 'red');
						}

						// Update horizontal progress bar
						const progressBar = $('#seo-score-progress');
						progressBar.val(score);
						progressBar.attr('max', 100);

						// Change progress bar color based on the score
						if (score >= 70) {
							seo - score - progress.css('background-color', '#4caf50'); // Green for high scores
						} else if (score >= 40) {
							progressBar.css('background-color', '#ff9800'); // Orange for medium scores
						} else {
							progressBar.css('background-color', '#f44336'); // Red for low scores
						}
					}

					// Bind events to fields
					$('#asseoMetaTitle, #asseoMetaDescription, #asseoMetaKeywords, #asseoFbTitle, #asseoTwTitle')
						.on('input blur', calculateSEOScore); // Trigger on input and when leaving the field

					$('#asseoRobotNoindex, #asseoRobotNofollow').on('change', calculateSEOScore);

					// Initial calculation
					calculateSEOScore();
				});
			})(jQuery);
		</script>
		<?php
	}



}

?>