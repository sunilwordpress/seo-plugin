<?php 

namespace app\Admin\Meta;

/* Exit if accessed directly. */
if (!defined('ABSPATH')) {
	exit;
}
class QuickEdit {
	
	public function __construct($columnName) {
		$currentScreen = get_current_screen();
		if (!empty($_GET['post_type']) && $_GET['post_type'] != $currentScreen->post_type) {
			return;
		}

		static $printNonce = true;
		if ($printNonce) {
			$printNonce = false;
			wp_nonce_field(ASSEO_PATH, 'asseo_nonce');
		}

		switch($columnName) {
			case 'seo_title': ?>
		<fieldset class="inline-edit-col-left clear">
			<div class="inline-edit-col">
				<label>
					<span class="title"><?php echo __('SEO Title', ASSEO_TXTDOMAIN); ?></span>
					<span class="input-text-wrap">
						<input class="seo_title" type="text" name="asseo_meta_title" placeholder="">
						<span><span class="seo_title_count" style="color: rgb(112, 192, 52);">0</span> / <?php echo __('70 recommended characters', ASSEO_TXTDOMAIN); ?></span></span>
				</label>
			</div>
		</fieldset>
		<?php break; case 'seo_description': ?>
		<fieldset class="inline-edit-col-left clear">
			<div class="inline-edit-col">
				<label>
					<span class="title"><?php echo __('SEO Desc.'); ?></span>
					<span class="input-text-wrap">
						<textarea class="seo_description" name="asseoMetaDescription"></textarea>
						<span><span class="seo_description_count" style="color: rgb(112, 192, 52);">0</span> / <?php echo __('160 recommended characters', ASSEO_TXTDOMAIN); ?></span>
					</span>
				</label>
			</div>
		</fieldset>
		<?php break; }
	}
}

?>